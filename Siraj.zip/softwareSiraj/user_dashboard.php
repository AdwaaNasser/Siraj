<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
require 'db_connect.php';

$allowedRole = 'panel_owner';
require 'auth_guard.php';

$user_id = $_SESSION['user_id'] ?? 1;
$admin_name = "Unknown User";
$userQuery = $conn->query("SELECT name FROM users WHERE user_id = $user_id");

$sql = "SELECT profile_pic FROM users WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
if (!empty($user['profile_pic']) && $user['profile_pic'] != 'default.png') {
    // Custom profile picture
    $profilepic = 'user-uploads/' . $user['profile_pic'];
} else {
    // Default profile picture
    $profilepic = 'Images/default.png';
}
if ($userQuery && $userQuery->num_rows > 0) {
    $admin_name = $userQuery->fetch_assoc()['name'];
}

/* ALL USER PANELS + LATEST ENVIRONMENTAL ROW PER PANEL */
$stmt = $conn->prepare("
SELECT 
    p.*,
    s.currentLevel,
    s.capacity AS storageCapacity,
    e.ambientTemperature,
    e.dustAccumulation,
    e.sunlightIntensity
FROM panel p
LEFT JOIN storage_unit s 
    ON p.storageID = s.storageID
LEFT JOIN enviromentaldata e
    ON e.enviromentalDataID = (
        SELECT e2.enviromentalDataID
        FROM enviromentaldata e2
        WHERE e2.panelID = p.panelID
        ORDER BY e2.timestamp DESC, e2.enviromentalDataID DESC
        LIMIT 1
    )
WHERE p.userID = ?
ORDER BY p.panelID ASC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$allPanels = $result->fetch_all(MYSQLI_ASSOC);

/* SHOW ONLY FIRST 3 ON DASHBOARD */
$calcPanels = $allPanels;
$panels = array_slice($allPanels, 0, 3);

/* REAL PANEL COUNT */
$stmt = $conn->prepare("SELECT COUNT(*) FROM panel WHERE userID = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_row();
$panel_count = (int)$row[0];

/* TOTAL ENERGY FROM DB */
$stmt = $conn->prepare("
SELECT SUM(r.value)
FROM reading r
JOIN sensor s ON r.sensorID = s.sensorID
JOIN panel p ON s.panelID = p.panelID
WHERE p.userID = ?
");

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_row();
$total_energy = round($row[0] ?? 0);

/* SMART CALCULATIONS */
$total_efficiency = 0;
$total_storage_pct = 0;
$calc_count = 0;

$chartLabels = [];
$tempData = [];
$efficiencyData = [];

foreach ($calcPanels as &$p){
    $temp = isset($p['ambientTemperature']) ? (float)$p['ambientTemperature'] : 0;
    $dust = isset($p['dustAccumulation']) ? (float)$p['dustAccumulation'] : 0;
    $panelCapacity = isset($p['capacity']) ? (float)$p['capacity'] : 100;
    $currentLevel = isset($p['currentLevel']) ? (float)$p['currentLevel'] : 0;
    $storageCapacity = isset($p['storageCapacity']) ? (float)$p['storageCapacity'] : 0;

    $dust_loss = $dust * 0.6;
    $temp_loss = $temp * 0.1;
    $efficiency = 100 - ($dust_loss + $temp_loss);

    if ($efficiency < 0) {
        $efficiency = 0;
    }

    $storagePercent = $storageCapacity > 0
        ? round(($currentLevel / $storageCapacity) * 100)
        : 0;

    $p['efficiency'] = round($efficiency);
    $p['storagePercent'] = $storagePercent;

    $total_efficiency += $efficiency;
    $total_storage_pct += $storagePercent;
    $calc_count++;

    $chartLabels[] = $p['name'];
    $tempData[] = round($temp, 1);
    $efficiencyData[] = round($efficiency, 1);
}
unset($p);

$avg_efficiency = $calc_count ? round($total_efficiency / $calc_count) : 0;
$avg_storage = $calc_count ? round($total_storage_pct / $calc_count) : 0;

/* STATIC FOR NOW */
$energy_change = 8;

$energy_class = $energy_change > 0 ? "positive" : "danger";
$storage_class = $avg_storage > 50 ? "positive" : "warning";
$efficiency_class = $avg_efficiency > 85 ? "positive" : "warning";
?>
<!DOCTYPE html>
<html>
<head>
  <title>SIRAJ | Dashboard</title>
  <style>
    h1,h2,h3,h4,p { margin:0; }

    body {
      margin:0;
      font-family:'Segoe UI', sans-serif;
    }


/* Background image */
body::before {
  content: "";
  position: fixed;
  inset: 0;

  background:url('Images/FieldBackground.jpg') center/cover no-repeat;

  z-index: -2;
}


    .container {
      padding:30px;
    }

        /* Header layout */
        .header-box {
            background: rgba(64, 94, 96, 0.85); border-radius: 25px; padding: 35px; margin-bottom: 30px;
            display: flex; justify-content: space-between; align-items: center;
            color: var(--n-cream-light); box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            flex-wrap: nowrap;
        }
        
        .brand-section {
            display: flex;
            align-items: center;
            gap: 15px; 
        }

        .logo-img { height: 60px; width: auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2)); }
        .header-box h1 {color:white; margin: 0; font-size: 2rem; }
        
        .stats-wrap { display: flex; gap: 0px; flex-shrink: 0; }
        .stat-item { 
       
        }


    .header-left {
      display:flex;
      align-items:center;
      gap:12px;
    }

    .logo {
      width:45px;
    }

    .notify-btn {
      background:#405E60;
      color:white;
      border:none;
      width:42px;
      height:42px;
      border-radius:50%;
      font-size:18px;
      cursor:pointer;
    }


.status-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:18px;
  margin-top:25px;
}

.status-card {
  background:#F8F4EB;
  padding:20px;
  border-radius:18px;
  box-shadow:0 6px 14px rgba(0,0,0,0.08);
}

.value {
  font-size:26px;
  font-weight:bold;
  color:#314F52;
}

    .status-card h4 {
      font-size:13px;
      color:#829193;
      margin-bottom:4px;
    }



    .sub {
      font-size:12px;
      margin-top:3px;
    }

    .positive { color:#2e7d32; }
    .warning { color:#d97706; }
    .danger { color:#c62828; }

    .grid {
      display:grid;
      grid-template-columns: 2fr 1fr;
      gap:25px;
      margin-top:25px;
      align-items:start;
    }

    .card {
      background:#F8F4EB;
      padding:22px;
      border-radius:18px;
      box-shadow:0 6px 14px rgba(0,0,0,0.08);
    }
.card h3 {
  margin-bottom:12px;
  color:#314F52;
}
    .panels-grid {
      display:grid;
      grid-template-columns: 1fr;
      gap:15px;
      margin-top:14px;
    }

    .panel {
      background:#ffffff;
      padding:16px 18px;
      border-radius:14px;
      border:1px solid rgba(0,0,0,0.05);
      display:flex;
      justify-content:space-between;
      align-items:center;
    }

    .panel-left b {
      font-size:15px;
      color:#314F52;
      display:block;
      margin-bottom:4px;
    }

    .panel-left p {
      font-size:13px;
      color:#829193;
      margin-top:2px;
    }

    .panel-right {
      text-align:right;
      display:flex;
      flex-direction:column;
      align-items:flex-end;
      gap:6px;
    }

    .panel-right img {
      width:70px;
      display:block;
      margin-left:auto;
    }

    .temp {
      font-size:13px;
      color:#314F52;
    }

    .badge {
      font-size:11px;
      padding:4px 10px;
      border-radius:12px;
      margin-top:8px;
      display:inline-block;
    }

    .active {
      background:rgba(46,125,50,0.12);
      color:#2e7d32;
    }

    .warning-bg {
      background:rgba(217,119,6,0.15);
      color:#d97706;
    }

    .faulty {
      background:rgba(198,40,40,0.15);
      color:#c62828;
    }

    .inactive {
      background:rgba(120,120,120,0.12);
      color:#666;
    }

    .show-more {
      margin-top:14px;
      text-align:right;
    }

    .show-more a {
      text-decoration:none;
      color:#405E60;
      font-weight:600;
      font-size:14px;
    }

    .show-more a:hover {
      text-decoration:underline;
    }

    .chart-wrap {
      position: relative;
      height: 320px;
      margin-top: 12px;
    }
    
    .header-actions {
  display: flex;
  align-items: center;
  gap: 8px; 
}

/* FIX logout style */
.logout-btn {
  background: rgba(255,255,255,0.15);
  color: white;
  text-decoration: none;
  padding: 8px 14px;
  border-radius: 10px;
  font-size: 13px;
  transition: 0.2s;
}

.logout-btn:hover {
  background: rgba(255,255,255,0.25);
}
.profile-btn {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  overflow: hidden; 
  cursor: pointer;
}

.profile-btn img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
  display: block;
  opacity: 75%;
}

    #sun_glow {
    position: fixed;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(251, 192, 45, 0.5) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
    border-radius: 50%;
    pointer-events: none;
z-index: 0;
filter: blur(35px);
    left: -150px;
    top: -150px;
    will-change: transform;
}
  </style>
</head>
<body>
    <div id="sun_glow"></div>

  <div class="container">

    <div class="header">
                <div class="header-box">
            <div class="brand-section">
                <a href="user_dashboard.php"><img src="images/logo.png" alt="SIRAJ Logo" class="logo-img"></a>
                <div>
                    <h1 style="margin: 0; line-height: 1;">SIRAJ Dashboard</h1>
                    <p style="margin: 5px 0 0 0; color:white;">Welcome back, <?php echo htmlspecialchars($admin_name); ?>.</p>
                </div>
            </div>

            <div class="stats-wrap">
                <div class="stat-item"></div>
                <div class="stat-item"></div>
                <div class="stat-item"></div>
            </div>
<div class="header-actions">
<a href="profile_page.php">
  <div class="profile-btn">
    <img src="<?php echo $profilepic; ?>" alt="Profile">
  </div>
</a>
  <a href="alerts.php">
    <button class="notify-btn" type="button">🔔</button>
  </a>

  <a href="logout.php" class="logout-btn">Log-Out</a>

</div>

        </div>


 
    </div>

    <div class="status-grid">
      <div class="status-card">
        <h4>Total Energy</h4>
        <div class="value"><?php echo $total_energy; ?> kWh</div>
        <div class="sub <?php echo $energy_class; ?>">+<?php echo $energy_change; ?>%</div>
      </div>

      <div class="status-card">
        <h4>Active Panels</h4>
        <div class="value"><?php echo $panel_count; ?></div>
        <div class="sub positive">Connected</div>
      </div>

      <div class="status-card">
        <h4>Storage</h4>
        <div class="value"><?php echo $avg_storage; ?>%</div>
        <div class="sub <?php echo $storage_class; ?>">Battery</div>
      </div>

      <div class="status-card">
        <h4>Efficiency</h4>
        <div class="value"><?php echo $avg_efficiency; ?>%</div>
        <div class="sub <?php echo $efficiency_class; ?>">Performance</div>
      </div>
    </div>

    <div class="grid">

      <div class="card">
          <a href="my_panels.php" style="text-decoration:none;"><h3>Your Panels</h3></a>

        <div class="panels-grid">
          <?php foreach ($panels as $p): ?>
            <?php
              $status = strtolower($p['status']);
              $badgeClass = 'inactive';

              if ($status === 'active') {
                  $badgeClass = 'active';
              } elseif ($status === 'warning') {
                  $badgeClass = 'warning-bg';
              } elseif ($status === 'faulty') {
                  $badgeClass = 'faulty';
              }
            ?>

            <div class="panel">
              <div class="panel-left">
                <b><?php echo htmlspecialchars($p['name']); ?></b>
                <p><?php echo htmlspecialchars($p['location']); ?></p>
                <span class="badge <?php echo $badgeClass; ?>">
                  <?php echo htmlspecialchars($p['status']); ?>
                </span>
              </div>

              <div class="panel-right">
                <img src="Images/panel.png" alt="Panel">
                <div class="temp">
                  🌡 <?php echo $p['ambientTemperature'] !== null ? htmlspecialchars($p['ambientTemperature']) : '--'; ?>°C
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="show-more">
          <a href="my_panels.php">Show More →</a>
        </div>
      </div>

      <div class="card">
        <h3>Performance Analysis</h3>
        <div class="chart-wrap">
          <canvas id="chart"></canvas>
        </div>
      </div>

    </div>
  </div>



  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
      
    const labels = <?php echo json_encode($chartLabels); ?>;
    const efficiencyData = <?php echo json_encode($efficiencyData); ?>;
    const tempData = <?php echo json_encode($tempData); ?>;
    

    new Chart(document.getElementById("chart"), {
      data: {
        labels: labels,
        datasets: [
          {
            type: 'line',
            label: 'Efficiency %',
            data: efficiencyData,
            borderColor: '#314F52',
            backgroundColor: 'rgba(49,79,82,0.08)',
            pointBackgroundColor: '#314F52',
            pointRadius: 4,
            tension: 0.35,
            yAxisID: 'y'
          },
          {
            type: 'bar',
            label: 'Temperature °C',
            data: tempData,
            backgroundColor: 'rgba(217,119,6,0.35)',
            borderColor: '#d97706',
            borderWidth: 1,
            borderRadius: 8,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            labels: {
              boxWidth: 18,
              color: '#314F52'
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: '#314F52'
            },
            grid: {
              display: false
            }
          },
          y: {
            type: 'linear',
            position: 'left',
            beginAtZero: true,
            max: 100,
            ticks: {
              color: '#314F52'
            },
            title: {
              display: true,
              text: 'Efficiency %',
              color: '#314F52'
            }
          },
          y1: {
            type: 'linear',
            position: 'right',
            beginAtZero: true,
            ticks: {
              color: '#d97706'
            },
            grid: {
              drawOnChartArea: false
            },
            title: {
              display: true,
              text: 'Temperature °C',
              color: '#d97706'
            }
          }
        }
      }
    });
  </script>
<script>
    const sun = document.getElementById('sun_glow');
    document.addEventListener('mousemove', (e) => {
        sun.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    });
</script>
</body>
</html>