<?php
include("db_connect.php");

$allowedRole = 'admin';
require 'auth_guard.php';
require "db_connect.php";

$admin_id = $_SESSION['user_id'];

$admin_name = "Unknown Admin";
$userQuery = $conn->query("SELECT name FROM users WHERE user_id = $admin_id");

if ($userQuery && $userQuery->num_rows > 0) {
    $admin_name = $userQuery->fetch_assoc()['name'];
}

$message = "";

// -----------------------------
// Handle threshold update
// -----------------------------
$message = "";

if (isset($_GET['message']) && $_GET['message'] == "updated") {
    $message = "Threshold updated successfully.";
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['update_threshold'])) {
        $thresholdId = (int)$_POST['threshold_id'];
        $newValue = (float)$_POST['value'];

        $sql = "UPDATE thresholds SET value = $newValue WHERE threshold_id = $thresholdId";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $message = "Threshold updated successfully.";
        } else {
            $message = "Error updating threshold.";
        }
    }
    header("Location: thresholds.php?message=updated");
    exit();
}

// -----------------------------
// Fetch thresholds
// -----------------------------
$sql = "SELECT * FROM thresholds ORDER BY type ASC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIRAJ | Thresholds</title>
    <style>
        h1,h2,h3,h4,p { margin:0; }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family:'Segoe UI', sans-serif;
            color:#314F52;
        }

        body::before {
            content:"";
            position:fixed;
            inset:0;
            z-index:-2;
        }
        .fixed-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: url('Images/FieldBackground.jpg') center/cover no-repeat fixed; z-index: -10; }
        .fixed-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.45); z-index: -9; }

        .container {
            padding:30px;
        }

        .logo-img {
            height: 60px;
            width: auto;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
        }

        .header-box {
            background: rgba(64, 94, 96, 0.85);
            border-radius: 25px;
            padding: 35px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            flex-wrap: wrap;
            gap: 18px;
        }

        .brand-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .brand-section h1 {
            margin: 0;
            line-height: 1;
            color: white;
        }

        .brand-section p {
            margin: 5px 0 0 0;
            color: white;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logout-btn {
            background: rgba(255,255,255,0.15);
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 10px;
            font-size: 13px;
            transition: 0.2s;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.25);
        }

        .message {
            background:#F8F4EB;
            color:#314F52;
            padding:14px 16px;
            border-radius:16px;
            margin-bottom:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .status-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
            gap:18px;
            margin-bottom:28px;
        }

        .status-card {
            background:#F8F4EB;
            padding:22px;
            border-radius:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .status-card h4 {
            font-size:14px;
            color:#829193;
            margin-bottom:10px;
        }

        .value {
            font-size:26px;
            font-weight:bold;
            color:#314F52;
        }

        .sub {
            font-size:13px;
            margin-top:8px;
        }

        .warning {
            color:#d97706;
        }

        .positive {
            color:#2e7d32;
        }

        .grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:24px;
        }

        .card {
            background:#F8F4EB;
            padding:24px;
            border-radius:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .card-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:16px;
            gap:10px;
        }

        .card h3 {
            color:#314F52;
        }

        .card-top span {
            font-size:12px;
            color:#829193;
        }

        .threshold-list {
            display:grid;
            gap:14px;
        }

        .threshold-preview {
            background:white;
            padding:16px;
            border-radius:14px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .threshold-preview-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:10px;
            margin-bottom:10px;
        }

        .threshold-preview-top h4 {
            font-size:14px;
            color:#314F52;
        }

        .threshold-preview-top span {
            font-size:13px;
            font-weight:bold;
            color:#314F52;
            white-space: nowrap;
        }

        .bar {
            width: 100%;
            height: 9px;
            background: #EDE9D2;
            border-radius: 999px;
            overflow: hidden;
        }

        .bar-fill {
            height: 100%;
            background: #405E60;
            border-radius: 999px;
        }

        .threshold-grid {
            display:grid;
            gap:14px;
        }

        .threshold-card {
            background:white;
            border-radius:14px;
            padding:16px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .threshold-card h3 {
            font-size:15px;
            color:#314F52;
            margin-bottom:12px;
        }

        .value-box {
            background:#EDE9D2;
            border-radius:14px;
            padding:12px;
            margin-bottom:12px;
        }

        .value-label {
            font-size:11px;
            color:#829193;
            margin-bottom:6px;
        }

        .value-number {
            font-size:18px;
            font-weight:bold;
            color:#314F52;
        }

        .threshold-card label {
            display: block;
            margin-bottom: 8px;
            font-size: 12px;
            font-weight: bold;
            color: #314F52;
        }

        .threshold-card input[type="number"] {
            width: 100%;
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px solid #829193;
            margin-bottom: 10px;
            font-size: 12px;
            background: #ffffff;
            color: #314F52;
            outline:none;
        }

        .threshold-card button {
            width: 100%;
            padding: 10px;
            border-radius: 12px;
            border: none;
            background: #314F52;
            color: #F8F4EB;
            font-size: 12px;
            cursor: pointer;
            transition:0.2s;
        }

        .threshold-card button:hover {
            background: #405E60;
        }

        .no-thresholds {
            background:#F8F4EB;
            padding:18px;
            border-radius:16px;
            color:#405E60;
            font-size:13px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        #sun_glow {
            position: fixed;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(251, 192, 45, 0.5) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0; 
            filter: blur(35px);
            left: -150px;
            top: -150px;
            will-change: transform;
        }

        @media (max-width: 1000px) {
            .grid {
                grid-template-columns:1fr;
            }
        }

        @media (max-width: 700px) {
            .container {
                padding:18px;
            }

            .header-box {
                padding:24px;
            }

            .brand-section {
                flex-direction:column;
                align-items:flex-start;
            }
        }
    </style>
</head>
<body>
        <div class="fixed-bg"></div>
    <div class="fixed-overlay"></div>
<div id="sun_glow"></div>

<div class="container">
    <div class="header-box">
        <div class="brand-section">
            <img src="images/logo.png" alt="SIRAJ Logo" class="logo-img">
            <div>
                <h1>Thresholds</h1>
                <p>Monitor and update system thresholds to ensure optimal performance and control.</p>
            </div>
        </div>

        <div class="header-actions">
            <a href="admin_dashboard.php" class="logout-btn">Dashboard</a>
            <a href="logout.php" class="logout-btn">Log-Out</a>
        </div>
    </div>

    <?php if (!empty($message)) { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <?php
    $thresholdsData = [];
    if ($result && mysqli_num_rows($result) > 0) {
        mysqli_data_seek($result, 0);
        while ($row = mysqli_fetch_assoc($result)) {
            $thresholdsData[] = $row;
        }
    }
    ?>

    <?php if (!empty($thresholdsData)) { ?>
        <div class="status-grid">
            <div class="status-card">
                <h4>Total Thresholds</h4>
                <div class="value"><?php echo count($thresholdsData); ?></div>
                <div class="sub positive">Configured in the system</div>
            </div>

            <div class="status-card">
                <h4>Highest Value</h4>
                <div class="value">
                    <?php
                    $values = array_column($thresholdsData, 'value');
                    echo max($values);
                    ?>
                </div>
                <div class="sub warning">Largest configured threshold</div>
            </div>

            <div class="status-card">
                <h4>Average Value</h4>
                <div class="value">
                    <?php
                    $values = array_column($thresholdsData, 'value');
                    echo round(array_sum($values) / count($values), 2);
                    ?>
                </div>
                <div class="sub positive">Average threshold value</div>
            </div>
        </div>

        <div class="grid">
            <div class="card">
                <div class="card-top">
                    <h3>Threshold Overview</h3>
                    <span>Current Values</span>
                </div>

                <div class="threshold-list">
                    <?php
                    foreach ($thresholdsData as $row) {
                        $type = strtolower(trim($row['type']));
                        $value = (float)$row['value'];

                        $referenceMax = 100;

                        if ($type == 'temperature') {
                            $referenceMax = 100;
                        } elseif ($type == 'dust accumulation') {
                            $referenceMax = 100;
                        } elseif ($type == 'energy production') {
                            $referenceMax = 100;
                        }

                        $percent = 0;
                        if ($referenceMax > 0) {
                            $percent = ($value / $referenceMax) * 100;
                        }

                        if ($percent > 100) {
                            $percent = 100;
                        }
                    ?>
                        <div class="threshold-preview">
                            <div class="threshold-preview-top">
                                <h4><?php echo htmlspecialchars($row['type']); ?></h4>
                                <span><?php echo htmlspecialchars($row['value']) . " " . htmlspecialchars($row['unit']); ?></span>
                            </div>
                            <div class="bar">
                                <div class="bar-fill" style="width: <?php echo round($percent, 2); ?>%;"></div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="card">
                <div class="card-top">
                    <h3>Update Thresholds</h3>
                    <span>Edit Values</span>
                </div>

                <div class="threshold-grid">
                    <?php foreach ($thresholdsData as $row) { ?>
                        <div class="threshold-card">
                            <h3><?php echo htmlspecialchars($row['type']); ?></h3>

                            <div class="value-box">
                                <div class="value-label">Current Value</div>
                                <div class="value-number">
                                    <?php echo htmlspecialchars($row['value']) . " " . htmlspecialchars($row['unit']); ?>
                                </div>
                            </div>

                            <form method="POST">
                                <input type="hidden" name="threshold_id" value="<?php echo $row['threshold_id']; ?>">

                                <label>New Value</label>
                                <input type="number" step="0.01" name="value" required
                                       value="<?php echo htmlspecialchars($row['value']); ?>">

                                <button type="submit" name="update_threshold">Update Threshold</button>
                            </form>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    <?php } else { ?>
        <div class="no-thresholds">
            No thresholds found.
        </div>
    <?php } ?>
</div>

<script>
    const sun = document.getElementById('sun_glow');
    document.addEventListener('mousemove', (e) => {
        sun.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    });
</script>
</body>
</html>