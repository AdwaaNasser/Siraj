<?php

session_start();

// Get user ID from session (real session, not hardcoded)
$userId = $_SESSION['user_id'] ?? null;

// Redirect to login if not logged in
if(!$userId) {
    header("Location: index.php");
    exit();
}

$userRole = $_SESSION['role'] ?? 'user';


include('db_connect.php'); 


// Process update request on the same page
$successMessage = '';
$errorMessage = '';

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])){
    
    $name = trim($_POST["name"] ?? '');
$email = trim($_POST["email"] ?? '');
$password = $_POST["password_hash"] ?? '';

$updateSuccess = true;

if (empty($name) || empty($email)) {
    $updateSuccess = false;
    $errorMessage = "Name and email cannot be empty.";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $updateSuccess = false;
    $errorMessage = "Please enter a valid email address.";
}

if ($updateSuccess) {
    $sql = "UPDATE users SET name=?, email=? WHERE user_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $name, $email, $userId);

    if (!$stmt->execute()) {
        $updateSuccess = false;
        $errorMessage = "Error updating profile information.";
    }
    $stmt->close();
}
    
    // Update password if user typed one
    if(!empty($password) && $updateSuccess){
        $passwordhash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET password_hash=? WHERE user_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $passwordhash, $userId);
        
        if(!$stmt->execute()){
            $updateSuccess = false;
            $errorMessage = "Error updating password.";
        }
        $stmt->close();
    }
    
    // Upload profile picture
    if(!empty($_FILES["profilepic"]["name"]) && $updateSuccess){
        $target_dir = "user-uploads/";
        
        if(!file_exists($target_dir)){
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = pathinfo($_FILES["profilepic"]["name"], PATHINFO_EXTENSION);
        $unique_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $unique_filename;
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES["profilepic"]["type"];
        
        if(in_array($file_type, $allowed_types)){
            if(move_uploaded_file($_FILES["profilepic"]["tmp_name"], $target_file)){
                $sql = "UPDATE users SET profile_pic=? WHERE user_id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $unique_filename, $userId);
                
                if(!$stmt->execute()){
                    $updateSuccess = false;
                    $errorMessage = "Error updating profile picture.";
                }
                $stmt->close();
            } else {
                $updateSuccess = false;
                $errorMessage = "Error uploading profile picture.";
            }
        } else {
            $updateSuccess = false;
            $errorMessage = "Invalid file type. Please upload JPG, PNG, GIF, or WEBP images only.";
        }
    }
    
    if($updateSuccess){
        $successMessage = "Profile updated successfully!";
    }
}
// Process delete account request
if(isset($_POST['delete_account'])) {
    // Delete user from database
    $sql = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    
    if($stmt->execute()) {
        // Destroy the session
        session_destroy();
        // Redirect to login page
        header("Location: index.php?success=2");
        exit();
    } else {
        $errorMessage = "Error deleting account. Please try again.";
    }
    $stmt->close();
}

// Fetch user data from the database (always get fresh data)
$sql = "SELECT name, email, profile_pic FROM users WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$name = $user['name'] ?? '';
$email = $user['email'] ?? '';
if (!empty($user['profile_pic']) && $user['profile_pic'] != 'default.png') {
    // Custom profile picture
    $profilepic = 'user-uploads/' . $user['profile_pic'];
} else {
    // Default profile picture
    $profilepic = 'Images/default.png';
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIRAJ | My Profile</title>
    <style>
        :root {
            --n-teal-med: #405E60;
            --n-teal-dark: #314F52;
            --n-cream-light: #f8f4eb;
            --n-sun-yellow: #fbc02d;
            --n-glass: rgba(255, 255, 255, 0.75);
        }

        html, body { 
            height: 100%; 
            margin: 0; 
            padding: 0; 
            overflow: hidden; 
        }

        .fixed-bg { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: url('Images/FieldBackground.jpg') center/cover no-repeat fixed; 
            z-index: -10; 
        }
        .fixed-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0, 0, 0, 0.5); 
            z-index: -9; 
        }

        #sun_glow {
            position: fixed; 
            width: 300px; 
            height: 300px;
            background: radial-gradient(circle, rgba(251, 192, 45, 0.6) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
            border-radius: 50%; 
            pointer-events: none; 
            z-index: -8; 
            filter: blur(35px);
            left: -150px; 
            top: -150px; 
            will-change: transform;
        }

        body { 
            font-family: 'Segoe UI', sans-serif; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            color: var(--n-teal-dark); 
        }

        .glass-form {
            background: var(--n-glass); 
            backdrop-filter: blur(20px);
            padding: 45px; 
            border-radius: 35px; 
            border: 1px solid rgba(255,255,255,0.4);
            box-shadow: 0 25px 60px rgba(0,0,0,0.4); 
            width: 420px; 
            z-index: 1;
            position: relative;
        }

        .edit-btn {
            position: absolute;
            top: 20px;
            right: 25px;
            background: var(--n-teal-med);
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
            color: white;
            font-size: 1.2rem;
        }
        .edit-btn:hover {
            background: var(--n-teal-dark);
            transform: scale(1.05);
        }

        h2 { 
            text-align: center; 
            margin-top: 0; 
            margin-bottom: 10px; 
            font-weight: 800; 
            color: var(--n-teal-dark); 
            letter-spacing: -0.5px; 
        }
        
        .sub {
            text-align: center;
            color: var(--n-teal-dark);
            opacity: 0.7;
            margin-bottom: 30px;
            font-size: 0.9rem;
        }

        .form-group { 
            margin-bottom: 22px; 
        }
        
        label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: 700; 
            font-size: 0.9rem; 
            opacity: 0.9; 
        }

        input {
            width: 100%; 
            padding: 14px; 
            border-radius: 12px; 
            border: 1px solid rgba(0,0,0,0.1);
            background: rgba(255,255,255,0.6); 
            font-size: 1rem; 
            color: var(--n-teal-dark);
            outline: none; 
            box-sizing: border-box; 
            transition: 0.3s;
        }
        
        input:focus { 
            border-color: var(--n-teal-med); 
            background: white; 
            box-shadow: 0 0 15px rgba(64,94,96,0.1); 
        }
        
        input:disabled {
            background: rgba(200,200,200,0.3);
            cursor: not-allowed;
            opacity: 0.7;
        }

        .profile-pic-container {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .profile-pic-img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid var(--n-teal-med);
            background: white;
        }
        
        .file-input-group {
            margin-top: 10px;
            display: none;
        }
        
        .file-input-group input {
            padding: 8px;
            font-size: 0.85rem;
        }

        .btn-save {
            width: 100%; 
            padding: 16px; 
            border-radius: 12px; 
            border: none;
            background: var(--n-teal-med); 
            color: white; 
            font-weight: 800;
            font-size: 1.1rem; 
            cursor: pointer; 
            transition: 0.3s; 
            margin-top: 15px;
            display: none;
        }
        
        .btn-save:hover { 
            background: var(--n-teal-dark); 
            transform: translateY(-3px); 
            box-shadow: 0 10px 20px rgba(0,0,0,0.15); 
        }

        .back-link { 
            display: block; 
            text-align: center; 
            margin-top: 20px; 
            color: var(--n-teal-dark); 
            text-decoration: none; 
            font-weight: 700; 
            font-size: 0.9rem; 
            opacity: 0.6; 
            transition: 0.3s; 
        }
        
        .back-link:hover { 
            opacity: 1; 
            transform: scale(1.05); 
        }

        .delete-btn {
            width: 100%;
            padding: 12px;
            border-radius: 12px;
            border: 1px solid #d32f2f;
            background: rgba(211, 47, 47, 0.1);
            color: #d32f2f;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 15px;
        }
        
        .delete-btn:hover {
            background: rgba(211, 47, 47, 0.2);
            transform: translateY(-2px);
        }

        .message {
            background: rgba(64, 94, 96, 0.9);
            color: white;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 0.9rem;
            width: 100%;
            backdrop-filter: blur(10px);
        }

        .error-message {
            background: rgba(211, 47, 47, 0.9);
        }

        .success-message {
            background: rgba(76, 175, 80, 0.9);
        }
    </style>
</head>
<body>

    <div class="fixed-bg"></div>
    <div class="fixed-overlay"></div>
    <div id="sun_glow"></div>

    <div class="glass-form">
        <button class="edit-btn" id="edit-icon" title="Edit Profile">✎</button>
        
        <h2>My Profile Page</h2>
        <p class="sub">View your personal information</p>
        
        <!-- Success Message -->
        <?php if($successMessage): ?>
            <div class="message success-message">
                ✓ <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        
        <!-- Error Message -->
        <?php if($errorMessage): ?>
            <div class="message error-message">
                ⚠️ <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" id="profile-form">
            <!-- Profile Picture Display -->
            <div class="profile-pic-container">
                <img src="<?php echo htmlspecialchars($profilepic); ?>" alt="Profile Picture" class="profile-pic-img" id="profile-pic-display">
            </div>
            
            <div class="file-input-group" id="file-input-group">
                <label>Change Profile Picture</label>
                <input type="file" name="profilepic" accept="image/*" id="profilepic-field">
            </div>

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" disabled id="name-field">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" disabled id="email-field">
            </div>

            <div class="form-group" id="password-group" style="display: none;">
                <label>New Password </label>
                <input type="password" name="password_hash" placeholder="Enter new password" id="password-field">
            </div>

            <button type="submit" name="update_profile" id="save-btn" class="btn-save">Update & Save</button>
        </form>
        
        <form method="POST" onsubmit="return confirm('Are you sure you want to permanently delete your account? This action cannot be undone!');">
    <button type="submit" name="delete_account" class="delete-btn" id="delete-account-btn">
         Delete Account
    </button>
</form>
        
        <a href="<?php echo ($userRole === 'admin') ? 'admin_dashboard.php' : 'user_dashboard.php'; ?>" class="back-link">← Back to Dashboard</a>
    </div>

    <script>
        const glow = document.getElementById('sun_glow');
        // Mouse tracking script
        document.addEventListener('mousemove', (e) => {
            window.requestAnimationFrame(() => {
                glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
            });
        });
        
        // Edit functionality
        const editIcon = document.getElementById('edit-icon');
        const saveBtn = document.getElementById('save-btn');
        const nameField = document.getElementById('name-field');
        const emailField = document.getElementById('email-field');
        const passwordGroup = document.getElementById('password-group');
        const fileInputGroup = document.getElementById('file-input-group');
        
        let isEditMode = false;
        
        // Store original values
        const originalName = nameField.value;
        const originalEmail = emailField.value;
        
        editIcon.addEventListener('click', function() {
            isEditMode = !isEditMode;
            
            if (isEditMode) {
                // Enable editing
                nameField.disabled = false;
                emailField.disabled = false;
                passwordGroup.style.display = 'block';
                fileInputGroup.style.display = 'block';
                saveBtn.style.display = 'block';
                editIcon.style.background = 'var(--n-sun-yellow)';
                editIcon.style.color = 'var(--n-teal-dark)';
                editIcon.title = 'Cancel Edit';
                document.getElementById('delete-account-btn').style.display = 'none';
            } else {
                // Disable editing without saving
                nameField.disabled = true;
                emailField.disabled = true;
                passwordGroup.style.display = 'none';
                fileInputGroup.style.display = 'none';
                saveBtn.style.display = 'none';
                editIcon.style.background = 'var(--n-teal-med)';
                editIcon.style.color = 'white';
                editIcon.title = 'Edit Profile';
                document.getElementById('delete-account-btn').style.display = 'block';
                
                // Reset form values to original
                nameField.value = originalName;
                emailField.value = originalEmail;
                document.getElementById('password-field').value = '';
                document.getElementById('profilepic-field').value = '';
            }
        });
        
        // Auto-hide messages after 3 seconds
        setTimeout(function() {
            const messages = document.querySelectorAll('.message');
            messages.forEach(function(msg) {
                msg.style.display = 'none';
            });
        }, 3000);
    </script>
</body>
</html>