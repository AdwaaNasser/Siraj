<?php
$allowedRole = 'panel_owner';
require 'auth_guard.php';

$userID = $_SESSION['user_id'] ?? 1;

require "db_connect.php";

/*Handle alert status change*/

if(isset($_POST['alertID']) && isset($_POST['status'])){

$alertID = $_POST['alertID'];
$status = $_POST['status'];

if($status == "Dismissed"){

$conn->query("UPDATE Alert SET status='Dismissed' WHERE alertID=$alertID");

}
else{

$stmt = $conn->prepare("UPDATE Alert SET status=? WHERE alertID=?");
$stmt->bind_param("si",$status,$alertID);
$stmt->execute();

}

}

/* Generate Alerts*/

$query = "
SELECT r.readingID, r.value, r.timestamp, s.type, s.unit, p.panelID, p.name as panel_name
FROM reading r
JOIN sensor s ON r.sensorID = s.sensorID
JOIN panel p ON s.panelID = p.panelID
WHERE p.userID = $userID
";

$result = $conn->query($query);

if(!$result){
die("Query error: ".$conn->error);
}

while($row = $result->fetch_assoc()){

$type = strtolower($row['type']);
$type = explode(" ", $type)[0];

$value = $row['value'];
$panelID = $row['panelID'];
$panelName = isset($row['panel_name']) ? $row['panel_name'] : "Panel " . $panelID;
$readingID = $row['readingID'];
$unit = $row['unit'];

/* format timestamp  */
$timestamp = date("d M Y - H:i", strtotime($row['timestamp']));

$threshold_query = "
SELECT threshold_id, value, condition_is
FROM thresholds
WHERE LOWER(type) LIKE '%$type%'
";

$threshold_result = $conn->query($threshold_query);

if(!$threshold_result){
die("Threshold query error: ".$conn->error);
}

while($t = $threshold_result->fetch_assoc()){

$thresholdID = $t['threshold_id'];
$threshold_value = $t['value'];
$condition = $t['condition_is'];

$alert=false;

if($condition == "higher" && $value > $threshold_value){
$alert=true;
}

if($condition == "lower" && $value < $threshold_value){
$alert=true;
}

$check = $conn->query("
SELECT alertID,status
FROM Alert
WHERE readingID=$readingID AND thresholdID=$thresholdID
");

if($alert){

if($check->num_rows == 0){

$title="WARNING detected on Panel $panelName";
$cause="$type value ($value $unit) is outside normal range";

/* determine environmental factor*/

switch($type){

case "temperature":
$factor = "ambient temperature";
break;

case "dust":
$factor = "dust accumulation";
break;

case "voltage":
$factor = "sunlight intensity";
break;

case "energy":
$factor = "ambient temperature and dust accumulation";
break;

default:
$factor = "environmental factors";

}

/* calculate difference*/

$difference = abs($value - $threshold_value);

/*build explanation*/

if($condition == "lower"){

$explanation = "$type on panel $panelID measured at $timestamp has the value of $value $unit, falling below the minimum $threshold_value $unit threshold by $difference $unit. This might be due to $factor in the area. Immediate action is advised to prevent potential impact.";

}

if($condition == "higher"){

$explanation = "$type on panel $panelID measured at $timestamp has the value of $value $unit, exceeding the maximum $threshold_value $unit threshold by $difference $unit. This might be due to $factor in the area. Immediate action is advised to prevent potential impact.";

}

/* INSERT ALERT*/

$conn->query("
INSERT INTO Alert(type,title,cause,explanation,readingID,thresholdID,userID,panelID)
VALUES('$type','$title','$cause','$explanation',$readingID,$thresholdID,$userID,$panelID)
");

$conn->query("
UPDATE panel
SET status='warning'
WHERE panelID=$panelID
");

}

}
else{

$conn->query("
DELETE FROM Alert
WHERE readingID=$readingID AND thresholdID=$thresholdID
");

}

}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Alerts</title>
<link rel="stylesheet" href="stylee.css">
</head>

<body id="notification-page">

<!-- Header Section -->
<header class="header">
    <div class="header-content">
        <div class="logo-text-container">
            <img src="logo.png" alt="SIRAJ Logo" class="logo">
            <div class="title-welcome-container">
                <h1>SIRAJ Notification Page</h1>
                
            </div>
        </div>
    </div>
    <div class="user-info">
        
        <?php
        // Fetch the count of active alerts from the database
        $alert_count_query = "SELECT COUNT(*) FROM Alert WHERE userID=$userID AND status='Active'";
        $result = $conn->query($alert_count_query);
        $alert_count = $result->fetch_row()[0];
        ?>
        <p>Active Alerts: <br><?php echo $alert_count; ?></p>
       
    </div>
</header>

<!-- Main Content Container -->
<div class="content-container">
    <!-- Filter Section -->
    <div class="filter-container">
        <br>
        <h3>Filter</h3><br>
        <form method="GET" action="">
            <label>
                <input type="radio" name="status_filter" value="All" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'All' ? 'checked' : ''; ?> /> All
            <br>
            </label>
            <label>
                <input type="radio" name="status_filter" value="Active" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'Active' ? 'checked' : ''; ?> /> Active
            <br></label>
            <label>
                <input type="radio" name="status_filter" value="Resolved" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'Resolved' ? 'checked' : ''; ?> /> Resolved
            <br></label>
           
            <button type="submit">Apply Filter</button>
        </form>
    </div>

    <!-- Notification Section -->
    <div class="notification-container">
       

        <?php
        /* Determine the filter status */
        $status_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : '';

        /* Query to fetch alerts based on selected filter status */
        $query = "
        SELECT alertID, title, cause, explanation, status, type, panelID
        FROM Alert
        WHERE userID=$userID";

        /* Apply the status filter to the query */
        if ($status_filter && $status_filter !== 'All') {
            $query .= " AND status='$status_filter'";
        }

        $query .= " ORDER BY alertID DESC";

        $alerts = $conn->query($query);

  if ($alerts->num_rows == 0) {
    echo "<h1 class='no-alerts'>No alerts!</h1>";
    echo "<p class='message'>your system doesn't have any problems</p>";
} else {
    while ($a = $alerts->fetch_assoc()) {
        // Get panel name from panel table
        $panelNameQuery = $conn->query("SELECT name FROM panel WHERE panelID=(SELECT panelID FROM Alert WHERE alertID=" . $a['alertID'] . ")");
        $panelName = ($panelNameQuery && $panelNameQuery->num_rows > 0) ? $panelNameQuery->fetch_assoc()['name'] : "Unknown Panel";
        
        // Get timestamp from reading table
        $timeQuery = $conn->query("SELECT timestamp FROM reading WHERE readingID=(SELECT readingID FROM Alert WHERE alertID=" . $a['alertID'] . ")");
        $readingTime = ($timeQuery && $timeQuery->num_rows > 0) ? date("d M Y - H:i", strtotime($timeQuery->fetch_assoc()['timestamp'])) : "Time not available";
        
        echo "<div class='alert ".strtolower($a['status'])."'>";
        
        // Warning image + title (side by side)
        echo "<div style='display: flex; align-items: center; gap: 10px; margin-bottom: 10px;'>";
        echo "<img src='warning.jpg' alt='Warning' style='width: 28px; height: 28px;' onerror='this.style.display=\"none\"'>";
        echo "<h3 style='margin: 0;'>".$a['title']."</h3>";
        echo "</div>";
        
        // ID and Type line
        echo "<div style='margin: 8px 0; font-size: 14px;'>";
        echo "<strong>ID:</strong> " . $panelID . " &nbsp;|&nbsp; <strong>Type:</strong> " . $a['type'];
        echo "</div>";
        
        
        
        // Cause
        echo "<p style='margin: 5px 0;'>".$a['cause']."</p>";
        
        // Hover content (hidden until hover)
        echo "<div class='alert-hover' style='max-height: 0; overflow: hidden; transition: max-height 0.3s ease;'>";
        echo "<hr style='margin: 10px 0;'>";
        echo "<p><strong>Time:</strong> " . $readingTime . "</p>";
        echo "<p class='explanation'>".$a['explanation']."</p>";
        echo "</div>";
        
        // Dropdown menu
        echo "<form method='POST' class='alert-menu'>";
        echo "<input type='hidden' name='alertID' value='".$a['alertID']."'>";
        echo "<select name='status' onchange='this.form.submit()'>";
        echo "<option value='Active' ".($a['status']=="Active"?"selected":"").">Active</option>";
        echo "<option value='Resolved' ".($a['status']=="Resolved"?"selected":"").">Resolved</option>";
        echo "<option value='Dismissed' ".($a['status']=="Dismissed"?"selected":"").">Dismissed</option>";
        echo "</select>";
        echo "</form>";
        
        echo "</div>";
    }
}
        ?>

    </div>
</div>

<script>
document.querySelectorAll(".alert").forEach(alert => {
    let hoverContent = alert.querySelector(".alert-hover");

    alert.addEventListener("mouseenter", () => {
        hoverContent.style.maxHeight = "300px";
    });

    alert.addEventListener("mouseleave", () => {
        hoverContent.style.maxHeight = "0";
    });
});
</script>

</body>
</html>