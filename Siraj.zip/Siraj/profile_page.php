
<?php
$allowedRole = 'panel_owner';
require 'auth_guard.php';

$userID = $_SESSION['user_id'] ?? 1;

require "db_connect.php";

$sql = "SELECT name,email,password_hash,profile_pic FROM users WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$name = $user['name'];
$email = $user['email'];
$profilepic = $user['profile_pic'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Profile</title>
<link rel="stylesheet" href="stylee.css">
</head>

<body class="profile-page">

<div class="profile-container">

<div class="profile-header">

<h1>My Profile Page</h1>

<img id="edit-icon" src="Images/settingss.jpg" style="cursor:pointer">

<p class="sub">View your personal information</p>

</div>


<form class="profile-info" action="update-profile.php" method="POST" enctype="multipart/form-data">
<button id="cancel-btn" style="display:none; position:absolute; top:10px; left:10px;">
✖
</button>
<div class="info-group">

<img id="profile-pic" src="<?php echo $profilepic; ?>" width="120">

<input type="file" name="profilepic" id="profile-upload" disabled>

</div>


<div class="info-group">

<label>Name</label>

<input type="text" name="name" value="<?php echo $name; ?>" disabled>

</div>


<div class="info-group">

<label>Email</label>

<input type="email" name="email" value="<?php echo $email; ?>" disabled>

</div>


<div class="info-group">

<label>New Password</label>

<input type="password" name="password" placeholder="Enter new password" disabled>

</div>


<button id="save-btn" type="submit" style="display:none;">
Update & Save 
</button>
 </form>

<form action="delete_account.php" method="POST">
    <button type="submit" class="delete-account-btn" id="delete-account-btn">
        <img src="delete-icon.png" class="delete-icon" alt="Delete Icon">
        <span class="delete-text">Delete Account</span>
    </button>
</form>
</div>

<script src="script.js"></script>

</body>

</html>