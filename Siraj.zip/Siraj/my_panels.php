<?php 
include('db_connect.php'); 

$allowedRole = 'panel_owner';
require 'auth_guard.php';

/* 1. SESSION CHECK
   In a production environment, redirect to login.php if session is missing.
   For now, we ensure the dynamic ID is used. */
if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 2; // Default for testing
    $_SESSION['user_name'] = "Reem Ali";
}
$current_user_id = $_SESSION['user_id'];
$user_display_name = $_SESSION['user_name'];

/* 2. DELETE LOGIC
   Ensures the panel belongs to the logged-in user before deletion. */
if(isset($_GET['delete_id'])) {
    $n_id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    
    // Verify ownership
    $check_owner = mysqli_query($conn, "SELECT userID FROM panel WHERE panelID = '$n_id' AND userID = '$current_user_id'");
    if(mysqli_num_rows($check_owner) > 0) {
        mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");
        mysqli_query($conn, "DELETE FROM alert WHERE panelID = '$n_id'");
        mysqli_query($conn, "DELETE FROM enviromentaldata WHERE panelID = '$n_id'");
        mysqli_query($conn, "DELETE FROM reading WHERE sensorID IN (SELECT sensorID FROM sensor WHERE panelID = '$n_id')");
        mysqli_query($conn, "DELETE FROM sensor WHERE panelID = '$n_id'");
        mysqli_query($conn, "DELETE FROM panel WHERE panelID = '$n_id' AND userID = '$current_user_id'");
        mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");
        $_SESSION['success_msg'] = "Panel #$n_id has been removed successfully.";
    }
    header("Location: my_panels.php");
    exit();
}

/* 3. FETCH STATISTICS
   Aggregates data based on the specific user ID. */

// Count total panels
$total_panels = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM panel WHERE userID = '$current_user_id'"))['c'];

// Count unique panels with active alerts
$active_alerts = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT panelID) as c FROM alert WHERE userID = '$current_user_id'"))['c'];

// Calculate total energy level (Sum of all linked storage units)
$storage_q = mysqli_query($conn, "SELECT SUM(s.currentLevel) as total_kwh 
                                        FROM storage_unit s 
                                        INNER JOIN panel p ON s.storageID = p.storageID 
                                        WHERE p.userID = '$current_user_id'");
$storage_row = mysqli_fetch_assoc($storage_q);
$total_val = $storage_row['total_kwh'] ? $storage_row['total_kwh'] : 0;
$total_power = round($total_val, 2) . " kWh";

// Fetch unique locations for sidebar filter
$noura_loc_query = mysqli_query($conn, "SELECT DISTINCT location FROM panel WHERE userID = '$current_user_id'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIRAJ | Manage Panels</title>
    <style>
        :root {
            --n-teal-med: #405E60; --n-teal-dark: #314F52;
            --n-cream-light: #f8f4eb; --n-sun-yellow: #fbc02d;
            --n-coral: #ff6b6b; --n-glass-card: rgba(255, 255, 255, 0.75); 
        }

        html, body { height: 100%; margin: 0; padding: 0; }
        
        /* Background layers */
        .fixed-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: url('field3.jpg') center/cover no-repeat fixed; z-index: -10; }
        .fixed-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.45); z-index: -9; }

        /* Mouse glow effect */
        #sun_glow {
            position: fixed; width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(251, 192, 45, 0.5) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
            border-radius: 50%; pointer-events: none; z-index: -8; filter: blur(35px);
            left: -150px; top: -150px; will-change: transform;
        }

        body { font-family: 'Segoe UI', sans-serif; color: var(--n-teal-dark); min-height: 100vh; }
        .container { max-width: 1400px; margin: 0 auto; padding: 30px; position: relative; z-index: 10; }

        /* Header layout */
        .header-box {
            background: rgba(64, 94, 96, 0.85); border-radius: 25px; padding: 35px; margin-bottom: 30px;
            display: flex; justify-content: space-between; align-items: center;
            color: var(--n-cream-light); box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            flex-wrap: nowrap;
        }
        
        .brand-section {
            display: flex;
            align-items: center;
            gap: 15px; 
        }

        .logo-img { height: 60px; width: auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2)); }
        .header-box h1 { margin: 0; font-size: 2rem; }
        
        .stats-wrap { display: flex; gap: 20px; flex-shrink: 0; }
        .stat-item { 
            background: rgba(255, 255, 255, 0.1); padding: 15px 25px; 
            border-radius: 15px; text-align: center; min-width: 130px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .stat-item h4 { margin: 0; font-size: 0.75rem; text-transform: uppercase; opacity: 0.8; }
        .stat-item p { margin: 5px 0 0 0; font-size: 1.6rem; font-weight: 800; }

        .success-banner {
            background: rgba(76, 175, 80, 0.2); backdrop-filter: blur(10px);
            color: #fff; padding: 15px; border-radius: 15px; margin-bottom: 25px;
            text-align: center; font-weight: bold; border: 1px solid rgba(76, 175, 80, 0.3);
            animation: fadeIn 0.5s ease;
        }

        .layout-grid { display: flex; gap: 40px; align-items: flex-start; }

        /* Sidebar Filters */
        .sidebar { 
            width: 300px; background: rgba(64, 94, 96, 0.9); 
            padding: 35px 25px; border-radius: 30px; 
            color: var(--n-cream-light); box-shadow: 0 15px 35px rgba(0,0,0,0.2); 
            flex-shrink: 0; 
        }
        .search-input { width: 100%; box-sizing: border-box; padding: 12px; border-radius: 10px; border: none; background: rgba(0,0,0,0.2); color: white; margin-bottom: 25px; outline: none; }
        .filter-cat h5 { margin: 20px 0 10px 0; color: var(--n-cream-light); font-size: 0.9rem; text-transform: uppercase; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px; }

        /* Panel Cards Grid */
        .content-main { flex-grow: 1; }
        .panel-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 30px; padding-bottom: 100px; }

        .noura-card {
            background: var(--n-glass-card); backdrop-filter: blur(15px);
            padding: 30px; border-radius: 25px; border: 1px solid rgba(255,255,255,0.3);
            cursor: pointer; position: relative; 
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.3s ease;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15); display: flex; flex-direction: column;
            pointer-events: auto;
        }
        .noura-card:hover { transform: translateY(-12px) scale(1.02); box-shadow: 0 15px 35px rgba(0,0,0,0.25); background: rgba(255, 255, 255, 0.85); }

        .card-body { display: flex; justify-content: space-between; align-items: center; }
        .card-panel-icon { width: 140px; height: auto; filter: drop-shadow(2px 5px 10px rgba(0,0,0,0.2)); }
        
        /* Status Pills */
        .status-pill { display: inline-block; padding: 5px 14px; border-radius: 30px; font-size: 0.85rem; font-weight: bold; margin-top: 10px; }
        .active-pill { background: #e8f5e9; color: #2e7d32; }
        .warning-pill { background: #fff3e0; color: #ef6c00; }
        .faulty-pill { background: #ffebee; color: #c62828; }
        .inactive-pill { background: #f5f5f5; color: #757575; }

        .no-results {
            display: none; grid-column: 1 / -1; text-align: center; padding: 60px; 
            color: #fff; background: rgba(255,255,255,0.1); border-radius: 25px; 
            backdrop-filter: blur(10px); border: 1px dashed rgba(255,255,255,0.2);
        }

        .btn-add-floating { 
            position: fixed; bottom: 40px; right: 40px; 
            background: var(--n-sun-yellow); color: var(--n-teal-dark); 
            padding: 18px 35px; border-radius: 50px; text-decoration: none; 
            font-weight: 800; box-shadow: 0 10px 25px rgba(251, 192, 45, 0.4); 
            transition: 0.3s ease; z-index: 1000;
        }
        .btn-add-floating:hover { transform: scale(1.1) translateY(-5px); background: #fff; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    </style>
</head>
<body>

    <div class="fixed-bg"></div>
    <div class="fixed-overlay"></div>
    <div id="sun_glow"></div>

    <div class="container">
        
        <div class="header-box">
            <div class="brand-section">
                <img src="logo.png" alt="SIRAJ Logo" class="logo-img">
                <div>
                    <h1 style="margin: 0; line-height: 1;">SIRAJ Manage Panels</h1>
                    <p style="margin: 5px 0 0 0;">Welcome back, <?php echo htmlspecialchars($user_display_name); ?>.</p>
                </div>
            </div>

            <div class="stats-wrap">
                <div class="stat-item"><h4>Total Panels</h4><p><?php echo $total_panels; ?></p></div>
                <div class="stat-item"><h4>Energy Level</h4><p><?php echo $total_power; ?></p></div>
                <div class="stat-item"><h4>Active Alerts</h4><p><?php echo $active_alerts; ?></p></div>
            </div>
        </div>

        <?php if(isset($_SESSION['success_msg'])): ?>
            <div id="success_banner" class="success-banner">
                ✅ <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?>
            </div>
            <script>
                setTimeout(() => {
                    const b = document.getElementById('success_banner');
                    if(b) { b.style.opacity = "0"; setTimeout(() => b.remove(), 600); }
                }, 4000);
            </script>
        <?php endif; ?>

        <div class="layout-grid">
            <div class="sidebar">
                <h3 style="margin-top:0;">Filters</h3>
                <input type="text" id="noura_search" class="search-input" onkeyup="applyFilters()" placeholder="Search ID...">
                
                <div class="filter-cat">
                    <h5>Status</h5>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="st" value="all" checked onchange="applyFilters()"> All Systems</label>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="st" value="Active" onchange="applyFilters()"> Active</label>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="st" value="Warning" onchange="applyFilters()"> Warning</label>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="st" value="Faulty" onchange="applyFilters()"> Faulty</label>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="st" value="Inactive" onchange="applyFilters()"> Inactive</label>
                </div>

                <div class="filter-cat">
                    <h5>Location</h5>
                    <label style="display:block; margin-bottom:10px;"><input type="radio" name="loc" value="all" checked onchange="applyFilters()"> All Regions</label>
                    <?php mysqli_data_seek($noura_loc_query, 0); while($l = mysqli_fetch_assoc($noura_loc_query)) { ?>
                        <label style="display:block; margin-bottom:10px;"><input type="radio" name="loc" value="<?php echo $l['location']; ?>" onchange="applyFilters()"> <?php echo $l['location']; ?></label>
                    <?php } ?>
                </div>

                <div class="filter-cat">
                    <h5>Alert Filters</h5>
                    <label style="display:block;"><input type="checkbox" id="check_alerts" onchange="applyFilters()"> Show Only Alerts</label>
                </div>
            </div>

            <div class="content-main">
                <div class="panel-grid" id="noura_container">
                    <?php
                    // Fetch panels only belonging to the dynamic current_user_id
                    $res = mysqli_query($conn, "SELECT p.*, (SELECT COUNT(*) FROM alert WHERE panelID = p.panelID) as a_count FROM panel p WHERE p.userID = '$current_user_id'");
                    while($row = mysqli_fetch_assoc($res)) {
                        $has_a = ($row['a_count'] > 0) ? 'yes' : 'no';
                        ?>
                        <div class="noura-card" data-id="<?php echo $row['panelID']; ?>" data-status="<?php echo $row['status']; ?>" data-location="<?php echo $row['location']; ?>" data-alert="<?php echo $has_a; ?>" onclick="location.href='view_panel_details.php?id=<?php echo $row['panelID']; ?>'">
                            <?php if($row['a_count'] > 0) echo '<div style="position:absolute; top:20px; right:20px; width:12px; height:12px; background:var(--n-coral); border-radius:50%; box-shadow: 0 0 10px var(--n-coral);"></div>'; ?>
                            
                            <div class="card-body">
                                <div>
                                    <h3 style="margin:0 0 10px 0;"><?php echo $row['name']; ?></h3>
                                    <p>ID: #<?php echo $row['panelID']; ?></p>
                                    <p>Loc: <?php echo $row['location']; ?></p>
                                    <span class="status-pill <?php 
                                        if($row['status'] == 'Active') echo 'active-pill'; 
                                        elseif($row['status'] == 'Warning') echo 'warning-pill';
                                        elseif($row['status'] == 'Faulty') echo 'faulty-pill';
                                        else echo 'inactive-pill'; 
                                    ?>"><?php echo $row['status']; ?></span>
                                </div>
                                <img src="panel.png" class="card-panel-icon">
                            </div>

                            <div style="margin-top:20px; padding-top:15px; border-top:1px solid rgba(0,0,0,0.05);">
                                <a href="edit_panel.php?id=<?php echo $row['panelID']; ?>" onclick="event.stopPropagation();" style="color:var(--n-teal-med); text-decoration:none; font-weight:700; margin-right:15px;">Edit</a>
                                <a href="#" onclick="event.stopPropagation(); nouraDelete(<?php echo $row['panelID']; ?>)" style="color:var(--n-coral); text-decoration:none; font-weight:700;">Delete</a>
                            </div>
                        </div>
                    <?php } ?>

                    <div id="noura_no_results" class="no-results">
                        <h2 style="margin: 0; opacity: 0.8;">🔍 No panels found.</h2>
                        <p style="margin: 10px 0 0 0; opacity: 0.6;">Try adjusting your filters or search term.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="add_panel.php" class="btn-add-floating">+ Add New Panel</a>

    <script>
        /* Cursor light tracking script */
        const sun = document.getElementById('sun_glow');
        document.addEventListener('mousemove', (e) => {
            sun.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
        });

        /* Client-side filter logic */
        function applyFilters() {
            let s = document.getElementById('noura_search').value.toUpperCase();
            let st = document.querySelector('input[name="st"]:checked').value;
            let l = document.querySelector('input[name="loc"]:checked').value;
            let a = document.getElementById('check_alerts').checked;
            
            let visibleCount = 0;
            document.querySelectorAll('.noura-card').forEach(c => {
                let mS = c.getAttribute('data-id').toUpperCase().indexOf(s) > -1;
                let mSt = (st === 'all' || c.getAttribute('data-status') === st);
                let mL = (l === 'all' || c.getAttribute('data-location') === l);
                let mA = (!a || c.getAttribute('data-alert') === 'yes');

                if (mS && mSt && mL && mA) {
                    c.style.display = ""; visibleCount++;
                } else {
                    c.style.display = "none";
                }
            });

            document.getElementById('noura_no_results').style.display = (visibleCount === 0) ? "block" : "none";
        }

        /* Delete confirmation helper */
        function nouraDelete(id) { 
            if(confirm("Delete Panel #" + id + "?")) window.location.href="my_panels.php?delete_id=" + id; 
        }
    </script>
</body>
</html>