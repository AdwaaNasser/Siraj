<?php 
include('db_connect.php'); 

$allowedRole = 'panel_owner';
require 'auth_guard.php';

// 1. Check for panel ID in URL
if(!isset($_GET['id'])) { header("Location: my_panels.php"); exit(); }
$noura_p_id = mysqli_real_escape_string($conn, $_GET['id']);

// 2. Get current logged-in user from session
$current_user_id = $_SESSION['user_id']; 

// 3. Fetch data for this specific panel and user
$noura_query = "SELECT p.*, s.storageID, s.capacity as s_cap, s.currentLevel, s.status as s_status, 
                e.weatherCondition, e.ambientTemperature, e.dustAccumulation, e.sunlightIntensity, e.timestamp as env_date
                FROM panel p
                LEFT JOIN storage_unit s ON p.storageID = s.storageID
                LEFT JOIN enviromentaldata e ON p.panelID = e.panelID
                WHERE p.panelID = '$noura_p_id' AND p.userID = '$current_user_id'
                ORDER BY e.timestamp DESC LIMIT 1";

$noura_res = mysqli_query($conn, $noura_query);
$data = mysqli_fetch_assoc($noura_res);

// 4. Verification
if(!$data) { echo "Access denied or panel not found."; exit(); }

/* --- CALCULATIONS LOGIC --- */

// Calculate efficiency losses based on dust and temperature
$dust_val = $data['dustAccumulation'];
$temp_val = $data['ambientTemperature'];

$dust_loss_pct = $dust_val * 0.6; 
$total_loss_pct = $dust_loss_pct + ($temp_val * 0.1); 

// Calculate final performance score
$final_perf_pct = 100 - $total_loss_pct;
if($final_perf_pct < 0) $final_perf_pct = 0; 

// Calculate current power output in Watts
$max_cap = $data['capacity']; 
$current_watt = round($max_cap * ($final_perf_pct / 100), 1);

// Calculate cumulative storage level
$sun_hours = 5.5; 
$daily_yield_kwh = ($current_watt * $sun_hours) / 1000;
$display_storage_level = $data['currentLevel'] + $daily_yield_kwh;

// Ensure storage level does not exceed capacity
if ($display_storage_level > $data['s_cap']) $display_storage_level = $data['s_cap'];

// Visual indicators (colors and status classes)
$temp_color = ($temp_val > 45) ? "#ff6b6b" : (($temp_val > 35) ? "#fbc02d" : "#2E7D32");
$stat = $data['status'];
$stat_class = ($stat == 'Active') ? 'active-pill' : (($stat == 'Warning') ? 'warning-pill' : (($stat == 'Faulty') ? 'faulty-pill' : 'inactive-pill'));

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SIRAJ | <?php echo $data['name']; ?> Details</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --n-teal-med: #405E60; --n-teal-dark: #314F52;
            --n-cream-light: #f8f4eb; --n-sun-yellow: #fbc02d;
            --n-glass: rgba(255, 255, 255, 0.85); --n-coral: #d32f2f;
        }

        html, body { height: 100%; margin: 0; padding: 0; }
        .fixed-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: url('field3.jpg') center/cover no-repeat fixed; z-index: -10; }
        .fixed-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.45); z-index: -9; }
        #sun_glow { position: fixed; width: 400px; height: 400px; background: radial-gradient(circle, rgba(251, 192, 45, 0.4) 0%, transparent 70%); border-radius: 50%; pointer-events: none; z-index: -8; filter: blur(50px); left: -200px; top: -200px; will-change: transform; }

        body { font-family: 'Segoe UI', sans-serif; color: var(--n-teal-dark); }
        .container { max-width: 1200px; margin: 0 auto; padding: 40px; position: relative; z-index: 1; }

        .top-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; margin-bottom: 30px; }
        .glass-box { background: var(--n-glass); backdrop-filter: blur(15px); border-radius: 30px; padding: 35px; border: 1px solid rgba(255,255,255,0.4); box-shadow: 0 15px 35px rgba(0,0,0,0.2); }

        .panel-info-header { display: flex; justify-content: space-between; align-items: flex-start; }
        .panel-main-titles h1 { margin: 0; font-size: 2.2rem; color: var(--n-teal-dark); }
        .large-panel-img { width: 180px; height: auto; filter: drop-shadow(0 10px 20px rgba(0,0,0,0.2)); }

        .status-pill { padding: 4px 15px; border-radius: 30px; font-weight: bold; font-size: 0.8rem; display: inline-block; margin-top: 10px; }
        .active-pill { background: #e8f5e9; color: #2e7d32; }
        .warning-pill { background: #fff3e0; color: #ef6c00; }
        .faulty-pill { background: #ffebee; color: #c62828; }

        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 30px; }
        .stat-card { background: rgba(0,0,0,0.03); padding: 15px; border-radius: 15px; text-align: center; }
        .stat-label { font-size: 0.75rem; text-transform: uppercase; opacity: 0.6; font-weight: bold; }
        .stat-value { font-size: 1.2rem; font-weight: 800; margin-top: 5px; color: var(--n-teal-med); }

        .right-stats h3 { margin-top: 0; border-bottom: 2px solid var(--n-sun-yellow); padding-bottom: 10px; }
        .metric-row { display: flex; justify-content: space-between; padding: 15px 0; border-bottom: 1px solid rgba(0,0,0,0.05); }

        .alert-card { background: rgba(255, 245, 245, 0.9); border: 2px solid var(--n-coral); padding: 25px; border-radius: 20px; display: flex; align-items: center; gap: 20px; box-shadow: 0 5px 20px rgba(211,47,47,0.15); margin-top: 30px; }
        .learn-more-link { display: inline-block; padding: 4px 12px; background: var(--n-coral); color: white; border-radius: 10px; text-decoration: none; font-size: 0.7rem; font-weight: bold; margin-left: 10px; }

        .loss-badge { background: rgba(211, 47, 47, 0.05); color: var(--n-coral); padding: 15px; border-radius: 15px; margin-top: 20px; font-weight: bold; border: 1px dashed var(--n-coral); text-align: center; display: block; }
        .back-btn { display: inline-block; margin-bottom: 20px; color: white; text-decoration: none; font-weight: bold; background: var(--n-teal-med); padding: 10px 25px; border-radius: 50px; }
    </style>
</head>
<body>

    <div class="fixed-bg"></div><div class="fixed-overlay"></div><div id="sun_glow"></div>

    <div class="container">
        <a href="my_panels.php" class="back-btn">← Back to Dashboard</a>

        <div class="top-layout">
            <div class="glass-box">
                <div class="panel-info-header">
                    <div class="panel-main-titles">
                        <h1><?php echo htmlspecialchars($data['name']); ?></h1>
                        <p>ID: #<?php echo $data['panelID']; ?> | <?php echo htmlspecialchars($data['location']); ?></p>
                        <span class="status-pill <?php echo $stat_class; ?>"><?php echo $stat; ?></span>
                    </div>
                    <img src="panel.png" class="large-panel-img">
                </div>

                <div class="stats-grid">
                    <div class="stat-card"><div class="stat-label">Current Output</div><div class="stat-value"><?php echo $current_watt; ?> W</div></div>
                    <div class="stat-card"><div class="stat-label">Performance</div><div class="stat-value" style="color:var(--n-sun-yellow)"><?php echo round($final_perf_pct, 1); ?>%</div></div>
                    <div class="stat-card"><div class="stat-label">Temperature</div><div class="stat-value" style="color:<?php echo $temp_color; ?>"><?php echo $temp_val; ?> °C</div></div>
                </div>

                <div class="stats-grid" style="margin-top: 15px;">
                    <div class="stat-card"><div class="stat-label">Weather</div><div class="stat-value"><?php echo $data['weatherCondition']; ?></div></div>
                    <div class="stat-card"><div class="stat-label">Sun Intensity</div><div class="stat-value"><?php echo $data['sunlightIntensity']; ?> W/m²</div></div>
                    <div class="stat-card"><div class="stat-label">Soiling Level</div><div class="stat-value"><?php echo $dust_val; ?>%</div></div>
                </div>

                <div class="loss-badge">
                    📉 Estimated Performance Loss: -<?php echo round($dust_loss_pct, 1); ?>% 
                    <div style="font-size: 0.75rem; font-weight: normal; margin-top: 4px; opacity: 0.8;">
                        (Due to dust accumulation on panel surface)
                    </div>
                </div>
            </div>

            <div class="glass-box right-stats">
                <h3>System Metrics</h3>
                <div class="metric-row"><span>Storage ID</span><strong>#<?php echo $data['storageID']; ?></strong></div>
                <div class="metric-row"><span>Storage Level</span><strong><?php echo round($display_storage_level, 2); ?> kWh</strong></div>
                <div class="metric-row"><span>Storage Status</span><strong style="color:var(--n-sun-yellow)"><?php echo $data['s_status']; ?></strong></div>
                
                <div style="margin-top: 60px; padding: 20px; background: rgba(0,0,0,0.03); border-radius: 20px; text-align: center;">
                    <small style="text-transform: uppercase; font-weight: bold; opacity: 0.5;">Last Update</small>
                    <div style="font-weight: 800; font-size: 0.9rem; margin-top: 5px; color: var(--n-teal-med);"><?php echo $data['env_date']; ?></div>
                </div>
            </div>
        </div>

        <div class="glass-box">
            <h3 style="margin-top:0;">Energy Production Trends</h3>
            <canvas id="energyChart" style="max-height: 300px;"></canvas>
        </div>

        <?php 
        $alert_q = mysqli_query($conn, "SELECT * FROM alert WHERE panelID = '$noura_p_id' LIMIT 1");
        if($alert_row = mysqli_fetch_assoc($alert_q)): 
        ?>
        <div class="alert-card">
            <div style="font-size: 2.2rem;">⚠️</div>
            <div>
                <h3 style="color:var(--n-coral); margin:0;">SYSTEM ALERT DETECTED</h3>
                <p style="margin:5px 0 0 0; color:#333; font-weight:600;">
                    <strong><?php echo htmlspecialchars($alert_row['title']); ?>:</strong> <?php echo htmlspecialchars($alert_row['type']); ?>
                    <a href="alerts.php#alert-<?php echo $alert_row['alertID']; ?>" class="learn-more-link">Learn more...</a>
                </p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Interactive sun glow movement
        const glow = document.getElementById('sun_glow');
        document.addEventListener('mousemove', (e) => {
            window.requestAnimationFrame(() => { glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`; });
        });

        // Initialize Comparison Chart
        const ctx = document.getElementById('energyChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Current Status'], 
                datasets: [
                    {
                        label: 'Actual Output (W)',
                        data: [<?php echo $current_watt; ?>],
                        backgroundColor: '#405E60',
                        borderRadius: 10,
                        barThickness: 40
                    },
                    {
                        label: 'Rated Capacity (W)',
                        data: [<?php echo $max_cap; ?>],
                        backgroundColor: 'rgba(251, 192, 45, 0.3)',
                        borderColor: '#fbc02d',
                        borderWidth: 2,
                        borderRadius: 10,
                        barThickness: 40
                    }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, labels: { color: '#314F52', font: { weight: 'bold' } } },
                    tooltip: { callbacks: { label: function(context) { return context.dataset.label + ': ' + context.raw + ' W'; } } }
                },
                scales: {
                    x: { beginAtZero: true, max: <?php echo $max_cap + 20; ?>, ticks: { color: '#314F52' }, title: { display: true, text: 'Power in Watts (W)', color: '#314F52' } },
                    y: { display: false }
                }
            }
        });
    </script>
</body>
</html>