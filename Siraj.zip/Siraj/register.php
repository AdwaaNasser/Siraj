<?php
session_start();
include('db_connect.php'); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Siraj Register</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:"Segoe UI", Tahoma, sans-serif;
}

body{
min-height:100vh;
display:flex;
justify-content:center;
align-items:center;

background:
linear-gradient(rgba(25,58,54,0.35),rgba(25,58,54,0.35)),
url("Images/FieldRiyadhBackground.jpg") center/cover no-repeat;
}

.register-box{
width:420px;
padding:40px;
border-radius:25px;
background:rgba(255,255,255,0.08);
backdrop-filter:blur(12px);
-webkit-backdrop-filter:blur(12px);
border:1px solid rgba(255,255,255,0.18);
box-shadow:0 20px 45px rgba(0,0,0,0.35);
color:white;
}

.log{
width:130px;
height:55px;
display:block;
margin:0 auto 15px auto;
}

.title{
font-size:30px;
font-weight:700;
margin-bottom:4px;
color:#ede9d2;
}

.subtitle{
font-size:15px;
color:#e5e5e5;
margin-bottom:20px;
}

.message{
margin-bottom:15px;
font-size:14px;
}

.error{
color:#ffb3b3;
}

.success{
color:#dff5d8;
}

.input-group{
margin-bottom:20px;
}

.input-group label{
display:block;
margin-bottom:6px;
font-weight:600;
}

.input-group input{
width:100%;
padding:12px;
background:transparent;
border:none;
border-bottom:1px solid rgba(255,255,255,0.6);
color:white;
outline:none;
font-size:15px;
}

.input-group input::placeholder{
color:#d9d9d9;
}

.register-btn{
width:100%;
padding:14px;
border:none;
border-radius:12px;
background:#314e52;
color:#ede9d2;
font-weight:700;
font-size:16px;
cursor:pointer;
transition:0.3s;
}

.register-btn:hover{
opacity:0.9;
transform:translateY(-2px);
}

.back-login{
text-align:center;
margin-top:18px;
font-size:14px;
}

.back-login a{
color:#ede9d2;
font-weight:bold;
text-decoration:none;
}

</style>
</head>

<body>

<div class="register-box">

<img src="Images/logo.png" class="log" alt="Siraj Logo">

<div class="title">Create account</div>
<div class="subtitle">Please enter your details</div>

<?php
if(isset($_GET["error"]) && $_GET["error"] == "empty"){
    echo "<p class='message error'>Please fill in all fields.</p>";
}

if(isset($_GET["error"]) && $_GET["error"] == "password"){
    echo "<p class='message error'>Passwords do not match.</p>";
}

if(isset($_GET["error"]) && $_GET["error"] == "exists"){
    echo "<p class='message error'>This email already exists.</p>";
}

if(isset($_GET["success"])){
    echo "<p class='message success'>Account created successfully.</p>";
}
?>

<form method="POST" action="process_register.php">

<div class="input-group">
<label>Full Name</label>
<input type="text" name="name" placeholder="Enter your full name" required>
</div>

<div class="input-group">
<label>E-mail</label>
<input type="email" name="email" placeholder="Enter your e-mail" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="password" name="password" placeholder="Enter your password" required>
</div>

<div class="input-group">
<label>Confirm Password</label>
<input type="password" name="confirm_password" placeholder="Confirm your password" required>
</div>

<button type="submit" class="register-btn">Create account</button>

</form>

<div class="back-login">
Already have an account?
<a href="index.php">Log in</a>
</div>

</div>

</body>
</html>