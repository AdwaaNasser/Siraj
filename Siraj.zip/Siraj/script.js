const editIcon = document.getElementById("edit-icon");
const inputs = document.querySelectorAll(".profile-info input");
const saveBtn = document.getElementById("save-btn");
const deleteBtn = document.getElementById("delete-account-btn");

let editMode = false;

console.log("Script loaded"); // Check if script runs

/* Edit profile toggle */
if (editIcon) {
    editIcon.addEventListener("click", function() {
        console.log("Edit icon clicked, editMode:", editMode); // Debug log
        
        if (!editMode) {
            // Enter edit mode
            editMode = true;
            inputs.forEach(input => input.disabled = false);
            editIcon.src = "done.jpg";
            saveBtn.style.display = "block";
            deleteBtn.style.display = "none";
            console.log("Entered edit mode");
        } else {
            // Pressed DONE - reload the page
            console.log("Reloading page to cancel changes");
            window.location.reload();
        }
    });
} else {
    console.log("Edit icon not found");
}

/* Delete account confirmation */
if (deleteBtn) {
    deleteBtn.addEventListener("click", function(e) {
        if (!confirm("Are you sure you want to delete your account?")) {
            e.preventDefault();
        }
    });
}