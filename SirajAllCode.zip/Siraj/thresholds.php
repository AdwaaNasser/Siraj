<?php
include('db_connect.php'); 
$allowedRole = 'admin';
require 'auth_guard.php';
$message = "";

// -----------------------------
// Handle threshold update
// -----------------------------
$message = "";

if (isset($_GET['message']) && $_GET['message'] == "updated") {
    $message = "Threshold updated successfully.";
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['update_threshold'])) {
        $thresholdId = (int)$_POST['threshold_id'];
        $newValue = (float)$_POST['value'];

        $sql = "UPDATE thresholds SET value = $newValue WHERE threshold_id = $thresholdId";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $message = "Threshold updated successfully.";
        } else {
            $message = "Error updating threshold.";
        }
    }
    header("Location: thresholds.php?message=updated");
    exit();
}

// -----------------------------
// Fetch thresholds
// -----------------------------
$sql = "SELECT * FROM thresholds ORDER BY type ASC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siraj | Thresholds</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f8fb;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        h1 {
            margin-bottom: 20px;
            color: #1f2d3d;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 8px;
            background-color: #e6f4ea;
            color: #1d6f42;
            font-weight: bold;
        }

        .threshold-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .threshold-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .threshold-card h3 {
            margin-top: 0;
            color: #1f2d3d;
        }

        .threshold-card p {
            margin: 10px 0;
            color: #555;
        }

        .threshold-card input[type="number"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 15px 0;
            box-sizing: border-box;
        }

        .threshold-card button {
            padding: 10px 15px;
            background-color: #1d6f42;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .threshold-card button:hover {
            background-color: #155532;
        }

        .no-thresholds {
            background: white;
            padding: 20px;
            border-radius: 10px;
            color: #666;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php">← Dashboard</a>
    <h1>Threshold Management</h1>

    <?php if (!empty($message)) { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <?php if (mysqli_num_rows($result) > 0) { ?>
        <div class="threshold-grid">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="threshold-card">
                    <h3><?php echo htmlspecialchars($row['type']); ?> Threshold</h3>
                    <p><strong>Current Value:</strong> 
                        <?php echo htmlspecialchars($row['value']) . " " . htmlspecialchars($row['unit']); ?>
                    </p>

                    <form method="POST">
                        <input type="hidden" name="threshold_id" value="<?php echo $row['threshold_id']; ?>">

                        <label>New Value:</label>
                        <input type="number" step="0.01" name="value" required
                            value="<?php echo htmlspecialchars($row['value']); ?>" >

                        <button type="submit" name="update_threshold">Update</button>
                    </form>
                </div>
            <?php } ?>
        </div>
    <?php } else { ?>
        <div class="no-thresholds">
            No thresholds found.
        </div>
    <?php } ?>
</div>

</body>
</html>
