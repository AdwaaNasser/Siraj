<?php
session_start();
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"] ?? '');
    $password = $_POST["password"] ?? '';

    if (empty($email) || empty($password)) {
        header("Location: index.php?error=empty");
        exit();
    }

    $stmt = $conn->prepare("SELECT user_id, name, email, password_hash, role, is_active FROM users WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        header("Location: index.php?error=invalid");
        exit();
    }

    $user = $result->fetch_assoc();

    if ((int)$user["is_active"] !== 1) {
        header("Location: index.php?error=inactive");
        exit();
    }

    if (!password_verify($password, $user["password_hash"])) {
        header("Location: index.php?error=invalid");
        exit();
    }

    $_SESSION["user_id"] = $user["user_id"];
    $_SESSION["name"] = $user["name"];
    $_SESSION["email"] = $user["email"];
    $_SESSION["role"] = $user["role"];

    header("Location: user_dashboard.php");
    exit();

} else {
    header("Location: index.php");
    exit();
}
?>