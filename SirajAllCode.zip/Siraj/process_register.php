<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $password = $_POST["password"] ?? '';
    $confirm_password = $_POST["confirm_password"] ?? '';

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: register.php?error=empty");
        exit();
    }

    if ($password !== $confirm_password) {
        header("Location: register.php?error=password");
        exit();
    }

    $check = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    if (!$check) {
        die("Prepare check failed: " . $conn->error);
    }

    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $check->close();
        header("Location: register.php?error=exists");
        exit();
    }
    $check->close();

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $role = "panel_owner";
    $is_active = 1;

    $stmt = $conn->prepare("
        INSERT INTO users (name, email, password_hash, role, is_active, created_at, profile_pic)
        VALUES (?, ?, ?, ?, ?, NOW(), 'default.jpg')
    ");

    if (!$stmt) {
        die("Prepare insert failed: " . $conn->error);
    }

    $stmt->bind_param("ssssi", $name, $email, $hashed_password, $role, $is_active);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: user_dashboard.php?success=1");
        exit();
    } else {
        die("Execute failed: " . $stmt->error);
    }

} else {
    header("Location: register.php");
    exit();
}
?>