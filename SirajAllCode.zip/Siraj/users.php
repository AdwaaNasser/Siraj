<?php
include('db_connect.php'); 

$allowedRole = 'admin';
require 'auth_guard.php';
// -----------------------------
// Handle activate / deactivate
// -----------------------------
$message = "";

if (isset($_GET['message'])) {
    if ($_GET['message'] == "activated") {
        $message = "User activated successfully.";
    } elseif ($_GET['message'] == "deactivated") {
        $message = "User deactivated successfully.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['activate_user'])) {
        $userId = (int)$_POST['user_id'];
        $sql = "UPDATE users SET is_active = 1 WHERE user_id = $userId";
        mysqli_query($conn, $sql);

        header("Location: users.php?message=activated");
        exit();
    }

    if (isset($_POST['deactivate_user'])) {
        $userId = (int)$_POST['user_id'];
        $sql = "UPDATE users SET is_active = 0 WHERE user_id = $userId";
        mysqli_query($conn, $sql);

        header("Location: users.php?message=deactivated");
        exit();
    }
}

// -----------------------------
// Get filter / search / sort
// -----------------------------
$search = "";
$statusFilter = "all";
$sortBy = "name";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

if (isset($_GET['status'])) {
    $statusFilter = $_GET['status'];
}

if (isset($_GET['sort'])) {
    $sortBy = $_GET['sort'];
}

// -----------------------------
// Build query
// -----------------------------
$sql = "SELECT * FROM users WHERE role = 'panel_owner'";

// search
if (!empty($search)) {
    $searchEscaped = mysqli_real_escape_string($conn, $search);
    $sql .= " AND (name LIKE '%$searchEscaped%' OR email LIKE '%$searchEscaped%')";
}

// filter
if ($statusFilter == "active") {
    $sql .= " AND is_active = 1";
} elseif ($statusFilter == "inactive") {
    $sql .= " AND is_active = 0";
}

// sort
if ($sortBy == "date") {
    $sql .= " ORDER BY created_at ASC";
} else {
    $sql .= " ORDER BY name ASC";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siraj | Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f8fb;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        h1 {
            margin-bottom: 20px;
            color: #1f2d3d;
        }

        .controls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            background: white;
            padding: 15px;
            border-radius: 10px;
        }

        .controls input,
        .controls select,
        .controls button {
            padding: 10px;
            font-size: 14px;
        }

        .controls button {
            background-color: #1d6f42;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .controls button:hover {
            background-color: #155532;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #e9f1ec;
        }

        .status-active {
            color: green;
            font-weight: bold;
        }

        .status-inactive {
            color: red;
            font-weight: bold;
        }

        .action-form {
            display: inline;
        }

        .activate-btn, .deactivate-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .activate-btn {
            background-color: #2e8b57;
            color: white;
        }

        .deactivate-btn {
            background-color: #c0392b;
            color: white;
        }

        .activate-btn:hover {
            background-color: #246b44;
        }

        .deactivate-btn:hover {
            background-color: #992d22;
        }

        .no-users {
            background: white;
            padding: 20px;
            border-radius: 10px;
            color: #666;
        }
        .message {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 8px;
            background-color: #e6f4ea;
            color: #1d6f42;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php">← Dashboard</a>
    <h1>Manage Users</h1>
    
    <?php if (!empty($message)) { ?>
    <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <form method="GET" class="controls">
        <input type="text" name="search" placeholder="Search by name or email" 
               value="<?php echo htmlspecialchars($search); ?>" >

        <select name="status">
            <option value="all" <?php if ($statusFilter == "all") echo "selected"; ?>>All Users</option>
            <option value="active" <?php if ($statusFilter == "active") echo "selected"; ?>>Active Users</option>
            <option value="inactive" <?php if ($statusFilter == "inactive") echo "selected"; ?>>Inactive Users</option>
        </select>

        <select name="sort">
            <option value="name" <?php if ($sortBy == "name") echo "selected"; ?>>Sort by Name</option>
            <option value="date" <?php if ($sortBy == "date") echo "selected"; ?>>Sort by Date Joined</option>
        </select>

        <button type="submit">Apply</button>
    </form>

    <?php if (mysqli_num_rows($result) > 0) { ?>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date Joined</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                        <td>
                            <?php if ($row['is_active'] == 1) { ?>
                                <span class="status-active">Active</span>
                            <?php } else { ?>
                                <span class="status-inactive">Inactive</span>
                            <?php } ?>
                        </td>
                        <td>
                            <form method="POST" class="action-form">
                                <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">

                                <?php if ($row['is_active'] == 1) { ?>
                                    <button type="submit" name="deactivate_user" class="deactivate-btn">Deactivate</button>
                                <?php } else { ?>
                                    <button type="submit" name="activate_user" class="activate-btn">Activate</button>
                                <?php } ?>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <div class="no-users">
            No users found.
        </div>
    <?php } ?>
</div>

</body>
</html>

