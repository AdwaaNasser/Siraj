<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Siraj Login</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:"Segoe UI", Tahoma, sans-serif;
}

body{
min-height:100vh;
display:flex;
justify-content:center;
align-items:center;

background:
linear-gradient(rgba(25,58,54,0.35),rgba(25,58,54,0.35)),
url("solar-bg.jpg") center/cover no-repeat;

}


.login-box{

width:420px;
padding:40px;

border-radius:25px;

background:rgba(255,255,255,0.08);
backdrop-filter:blur(12px);
-webkit-backdrop-filter:blur(12px);

border:1px solid rgba(255,255,255,0.18);

box-shadow:0 20px 45px rgba(0,0,0,0.35);

color:white;

}


.log{
    width:130px;
    height:55px;
    display:block;
    margin:0 auto 10px auto;
    margin-bottom:15px;
}


.title{
font-size:30px;
font-weight:700;
margin-bottom:4px;
color: #ede9d2;
}

.subtitle{
font-size:15px;
color:#e5e5e5;
margin-bottom:30px;
}


.input-group{
margin-bottom:20px;
}

.input-group label{
display:block;
margin-bottom:6px;
font-weight:600;
}

.input-group input{

width:100%;
padding:12px;

background:transparent;

border:none;
border-bottom:1px solid rgba(255,255,255,0.6);

color:white;

outline:none;
font-size:15px;

}

.input-group input::placeholder{
color:#d9d9d9;
}


.options{

display:flex;
justify-content:space-between;
font-size:14px;

margin:15px 0 25px;

}

.options a{
color:#ede9d2;
text-decoration:none;
}


.login-btn{

width:100%;
padding:14px;

border:none;

border-radius:12px;

background: #314e52;

color: #ede9d2;

font-weight:700;
font-size:16px;

cursor:pointer;

transition:0.3s;

}

.login-btn:hover{
opacity:0.9;
transform:translateY(-2px);
}


.register{

text-align:center;
margin-top:18px;

font-size:14px;

}

.register a{

color:#ede9d2;
font-weight:bold;
text-decoration:none;

}

</style>
</head>

<body>

<div class="login-box">

<img src="log.png" class="log" alt="Siraj Logo">

<div class="title">Welcome back</div>
<div class="subtitle">Please enter your details</div>
<?php
if(isset($_GET["error"]) && $_GET["error"] == "empty"){
    echo "<p style='color:#ffb3b3; margin-bottom:15px;'>Please fill in all fields.</p>";
}

if(isset($_GET["invalid"])){
    echo "<p style='color:#ffb3b3; margin-bottom:15px;'>Invalid email or password.</p>";
}
?>
<form method="POST" action="process_login.php">

<div class="input-group">
<label>E-mail</label>
<input type="email" name="email" placeholder="Enter your e-mail" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="password" name="password" placeholder="Enter your password" required>
</div>

<div class="options">
<label><input type="checkbox" name="remember"> Remember me</label>
<a href="#">Forgot password?</a>
</div>

<button type="submit" class="login-btn">Log in</button>

</form>

<div class="register">
Don’t have an account?
<a href="register.php">Create new account</a>
</div>

</div>

</body>
</html>