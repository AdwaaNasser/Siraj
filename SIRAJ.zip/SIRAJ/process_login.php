<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        header("Location: login.php?error=empty");
        exit();
    }

    if ($email == "admin@siraj.com" && $password == "admin123") {

        $_SESSION["user"] = "Admin";

        header("Location: dashboard.php");
        exit();
    }

    if ($email == "owner@siraj.com" && $password == "1234") {

        $_SESSION["user"] = "Panel Owner";

        header("Location: dashboard.php");
        exit();
    }

    header("Location: login.php?invalid=1");
    exit();
}
?>