<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $confirm_password = trim($_POST["confirm_password"]);

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: register.php?error=empty");
        exit();
    }

    if ($password !== $confirm_password) {
        header("Location: register.php?error=password");
        exit();
    }

    header("Location: register.php?success=1");
    exit();

} else {
    header("Location: register.php");
    exit();
}
?>