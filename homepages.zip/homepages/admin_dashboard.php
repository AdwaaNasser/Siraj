<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db_connection.php';

$admin_name = $_SESSION['user_name'] ?? "Admin";

/* USERS */
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role='panel_owner'");
$total_users = $stmt->fetchColumn();

/* PANELS */
$stmt = $pdo->query("SELECT COUNT(*) FROM panel");
$total_panels = $stmt->fetchColumn();

/* ACTIVE ALERTS */
$stmt = $pdo->query("SELECT COUNT(*) FROM alert WHERE status='Active'");
$active_alerts = $stmt->fetchColumn();

/* SYSTEM HEALTH */
$total_alerts = $pdo->query("SELECT COUNT(*) FROM alert")->fetchColumn();
$health = $total_alerts == 0 ? 100 : max(60, 100 - ($total_alerts * 5));

/* ACTIVE ISSUES BY TYPE */
$stmt = $pdo->query("
SELECT type, COUNT(*) as total
FROM alert
WHERE status='Active'
GROUP BY type
");
$alerts_by_type = $stmt->fetchAll();

/* USERS PREVIEW */
$stmt = $pdo->query("
SELECT name, email 
FROM users 
WHERE role='panel_owner'
ORDER BY created_at DESC
LIMIT 3
");
$users_preview = $stmt->fetchAll();

/* THRESHOLDS */
$stmt = $pdo->query("
SELECT type, value, unit
FROM thresholds
LIMIT 3
");
$thresholds = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
<title>SIRAJ Admin</title>

<style>
h1,h2,h3,h4,p { margin:0; }

body {
  margin:0;
  font-family:'Segoe UI', sans-serif;
}

/* BACKGROUND */
body::before {
  content:"";
  position:fixed;
  inset:0;
  background:url('images/bg2.jpg') center/cover no-repeat;
  filter:blur(8px);
  transform:scale(1.1);
  z-index:-2;
}

.container { padding:30px; }

/* HEADER */
.header {
  background:#314F52;
  color:white;
  padding:16px 22px;
  border-radius:18px;
  display:flex;
  align-items:center;
}

.header-left {
  display:flex;
  align-items:center;
  gap:12px;
}

.logo { width:38px; }

/* STATUS GRID */
.status-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:18px;
  margin-top:25px;
}

.status-card {
  background:#F8F4EB;
  padding:20px;
  border-radius:18px;
  box-shadow:0 6px 14px rgba(0,0,0,0.08);
}

.value {
  font-size:26px;
  font-weight:bold;
  color:#314F52;
}

.sub {
  font-size:13px;
  margin-top:6px;
}

.positive { color:#2e7d32; }
.warning { color:#d97706; }

/* GRID */
.grid {
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:25px;
  margin-top:25px;
}

/* CARD */
.card {
  background:#F8F4EB;
  padding:22px;
  border-radius:18px;
  box-shadow:0 6px 14px rgba(0,0,0,0.08);
}

.card h3 {
  margin-bottom:12px;
  color:#314F52;
}

/* USERS GRID */
.users-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(120px,1fr));
  gap:15px;
  margin-top:15px;
}

.user-card {
  background:white;
  padding:15px;
  border-radius:14px;
  text-align:center;
  box-shadow:0 4px 10px rgba(0,0,0,0.06);
}

.user-img {
  width:50px;
  margin-bottom:10px;
}

.user-name {
  font-weight:600;
  color:#314F52;
}

.user-email {
  font-size:12px;
  color:#829193;
}

/* THRESHOLDS */
.threshold-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(120px,1fr));
  gap:15px;
  margin-top:15px;
}

.threshold-card {
  background:white;
  padding:16px;
  border-radius:14px;
  text-align:center;
  box-shadow:0 4px 10px rgba(0,0,0,0.06);
}

.th-title {
  font-size:12px;
  color:#829193;
}

.th-value {
  font-size:22px;
  font-weight:bold;
  color:#314F52;
}

/* BUTTON */
.btn {
  display:inline-block;
  margin-top:10px;
  padding:10px 14px;
  background:#314F52;
  color:white;
  border-radius:12px;
  text-decoration:none;
  font-size:13px;
}

.btn-container {
  text-align:center;
  margin-top:15px;
}
</style>
</head>

<body>

<div class="container">

<!-- HEADER -->
<div class="header">
  <div class="header-left">
    <img src="images/logo.png" class="logo">
    <div>
      <h2>SIRAJ Admin</h2>
      <p>Welcome <?php echo htmlspecialchars($admin_name); ?></p>
    </div>
  </div>
</div>

<!-- STATUS -->
<div class="status-grid">

  <!-- ACTIVE ISSUES -->
  <div class="status-card">
    <h4>Active Issues</h4>

    <?php if(count($alerts_by_type) > 0): ?>
      <?php foreach($alerts_by_type as $a): ?>
        <div class="sub warning">
          <?php echo ucfirst($a['type']); ?>: <?php echo $a['total']; ?>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="sub positive">No Issues</div>
    <?php endif; ?>
  </div>

  <div class="status-card">
    <h4>Total Panels</h4>
    <div class="value"><?php echo $total_panels; ?></div>
    <div class="sub">Installed</div>
  </div>

  <div class="status-card">
    <h4>Total Users</h4>
    <div class="value"><?php echo $total_users; ?></div>
    <div class="sub">Active</div>
  </div>

  <div class="status-card">
    <h4>System Health</h4>
    <div class="value"><?php echo $health; ?>%</div>
    <div class="sub positive">Overall Status</div>
  </div>

</div>

<!-- BODY -->
<div class="grid">

<!-- USERS -->
<div class="card">
  <h3>Users Overview</h3>

  <div class="users-grid">
    <?php foreach($users_preview as $u): ?>
      <div class="user-card">
        <img src="images/user.png" class="user-img">
        <div class="user-name"><?php echo $u['name']; ?></div>
        <div class="user-email"><?php echo $u['email']; ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="btn-container">
    <a href="users.php" class="btn">Manage Users</a>
  </div>
</div>

<!-- THRESHOLDS -->
<div class="card">
  <h3>Thresholds</h3>

  <div class="threshold-grid">
    <?php foreach($thresholds as $t): ?>
      <div class="threshold-card">
        <div class="th-title"><?php echo $t['type']; ?> Limit</div>
        <div class="th-value">
          <?php echo $t['value'] . " " . $t['unit']; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="btn-container">
    <a href="thresholds.php" class="btn">Manage Thresholds</a>
  </div>
</div>

</div>

</div>

</body>
</html>