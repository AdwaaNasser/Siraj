<?php
$host = "localhost:8889"; // VERY IMPORTANT
$dbname = "siraj_db";
$username = "root";
$password = "root"; // MAMP default

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>