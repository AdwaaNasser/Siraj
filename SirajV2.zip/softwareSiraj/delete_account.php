<?php
require "db_connect.php";

$allowedRole = 'panel_owner';
require 'auth_guard.php';


$userID = $_SESSION['user_id'];




// أخيراً حذف المستخدم
$conn->query("DELETE FROM users WHERE user_id = $userID");

// تحويل لصفحة ثانية
session_unset();
session_destroy();
header("Location: index.php?success=2");
exit();
?>