<?php
$allowedRole = 'panel_owner';
require 'auth_guard.php';

$userID = $_SESSION['user_id'] ?? 1;

require "db_connect.php";


/* Retrieve readings with sensor types */
$query = "
SELECT s.type, r.value, s.panelID
FROM sensor s
JOIN reading r ON r.sensorID = s.sensorID
WHERE s.userID = $userID
";

$result = $conn->query($query);

while($row = $result->fetch_assoc()){

    $type = $row['type'];
    $value = $row['value'];
    $panelID = $row['panelID'];

    /* get thresholds for that type */
    $threshold_query = "
    SELECT value, condition_is, unit
    FROM Threshold
    WHERE type='$type'
    ";

    $threshold_result = $conn->query($threshold_query);

    while($t = $threshold_result->fetch_assoc()){

        $threshold_value = $t['value'];
        $condition = $t['condition_is'];
        $unit = $t['unit'];

        $alert = false;

        if($condition == "higher" && $value > $threshold_value){
            $alert = true;
        }

        if($condition == "lower" && $value < $threshold_value){
            $alert = true;
        }

        if($alert){

            $title = "Abnormal reading detected on $panelID";
            $cause = "$type value ($value $unit) is outside normal range";

            $insert = "
            INSERT INTO Alert(type,title,cause,Explanation)
            VALUES('$type','$title','$cause','')
            ";

            $conn->query($insert);
        }

    }
}
?>