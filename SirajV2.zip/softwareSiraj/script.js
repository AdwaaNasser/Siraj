const editIcon = document.getElementById("edit-icon");
const inputs = document.querySelectorAll(".profile-info input");
const saveBtn = document.getElementById("save-btn");
const deleteBtn = document.getElementById("delete-account-btn");
const passwordGroup = document.getElementById("password-group");
const profileUpload = document.getElementById("profile-upload");

let editMode = false;

console.log("Script loaded");

/* Edit profile toggle */
if (editIcon) {
    editIcon.addEventListener("click", function() {
        console.log("Edit icon clicked, editMode:", editMode);

        if (!editMode) {
            // Enter edit mode
            editMode = true;
            inputs.forEach(input => input.disabled = false);
            editIcon.src = "done.jpg";
            saveBtn.style.display = "block";
            if (deleteBtn) deleteBtn.style.display = "none";

            // Enable profile pic upload
            if (profileUpload) profileUpload.disabled = false;

            console.log("Entered edit mode");
        } else {
            // Submit form on DONE
            console.log("Submitting form");
            document.querySelector(".profile-info").submit();
        }
    });
} else {
    console.log("Edit icon not found");
}

/* Success message — auto-hide after 3 seconds */
// Success message handling
function showSuccessMessage(el) {
    if (!el) return;
    const text = el.innerText || el.textContent;
    if (text.trim() === "") return;

    el.style.display = "block";
    el.style.opacity = "1";          // force it visible

    setTimeout(() => {
        el.style.opacity = "0";
        setTimeout(() => {
            el.style.display = "none";
            el.innerText = "";
        }, 500);
    }, 3000);
}

;