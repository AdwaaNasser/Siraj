<?php
$conn = mysqli_connect("localhost", "root", "root", "siraj_db",8889);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>