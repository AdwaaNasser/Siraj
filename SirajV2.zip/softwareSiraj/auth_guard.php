<?php

session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: index.php?error=need_log_in");
    exit();
}

// role check
if (isset($allowedRole) && $_SESSION['role'] !== $allowedRole) {
    header("Location: index.php?error=Access_denied");
    exit();
}

?> 