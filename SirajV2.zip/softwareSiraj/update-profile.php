<?php
require "db_connect.php";

$allowedRole = 'panel_owner';
require 'auth_guard.php';

$userId = $_SESSION['user_id'];


if($_SERVER["REQUEST_METHOD"] == "POST"){

$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password_hash"];


/* update name + email */

$sql = "UPDATE users SET name=?, email=? WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi",$name,$email,$userId);
$stmt->execute();


/* update password if user typed one */

if(!empty($password)){

$passwordhash = password_hash($password,PASSWORD_DEFAULT);

$sql = "UPDATE users SET password_hash=? WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si",$passwordhash,$userId);
$stmt->execute();

}


/* upload profile picture */

if(!empty($_FILES["profilepic"]["name"])){

$target = "" . basename($_FILES["profilepic"]["name"]);

move_uploaded_file($_FILES["profilepic"]["tmp_name"],$target);

$sql = "UPDATE users SET profile_pic=? WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si",$target,$userId);
$stmt->execute();

}

header("Location: profile_page.php");
exit();

}
?>