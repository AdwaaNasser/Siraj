<?php 
include('db_connect.php'); 

$allowedRole = 'panel_owner';
require 'auth_guard.php';

$error_msg = "";
$n_id = "";

// 1. Check if panel ID is provided in the URL
if(isset($_GET['id'])) {
    $n_id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Get current logged-in user from session
    $current_user_id = $_SESSION['user_id']; 

    // Fetch panel data only if it belongs to the current user
    $res = mysqli_query($conn, "SELECT * FROM panel WHERE panelID = '$n_id' AND userID = '$current_user_id'");
    $data = mysqli_fetch_assoc($res);
    
    // Redirect if panel not found or access denied
    if(!$data) { 
        header("Location: my_panels.php"); 
        exit(); 
    }
} else {
    header("Location: my_panels.php");
    exit();
}

// 2. Update logic upon form submission
if(isset($_POST['update_panel'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $loc = mysqli_real_escape_string($conn, $_POST['location']);
    $cap = floatval($_POST['capacity']);
    $stat = mysqli_real_escape_string($conn, $_POST['status']);

    // Validate capacity range (0-400 W)
    if($cap < 0 || $cap > 400) {
        $error_msg = "Error: Capacity must be between 0 and 400 W.";
    } else {
        // Check if the new name is already used by another of the user's panels
        $check_sql = "SELECT * FROM panel WHERE name='$name' AND userID='$current_user_id' AND panelID != '$n_id'";
        $check_res = mysqli_query($conn, $check_sql);
        
        if(mysqli_num_rows($check_res) > 0) {
            $error_msg = "Error: The name '$name' is already taken by another panel.";
        } else {
            // Execute the update in the database
            $update_sql = "UPDATE panel SET name='$name', location='$loc', capacity='$cap', status='$stat' 
                           WHERE panelID='$n_id' AND userID='$current_user_id'";
            
            if(mysqli_query($conn, $update_sql)) {
                $_SESSION['success_msg'] = "Panel '$name' has been updated successfully!";
                header("Location: my_panels.php");
                exit();
            } else {
                $error_msg = "Database Error: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIRAJ | Edit Panel #<?php echo $n_id; ?></title>
    <style>
        :root {
            --n-teal-med: #405E60; --n-teal-dark: #314F52;
            --n-cream-light: #f8f4eb; --n-sun-yellow: #fbc02d;
            --n-glass: rgba(255, 255, 255, 0.75);
        }

        html, body { height: 100%; margin: 0; padding: 0; overflow: hidden; }

        /* Fixed Background and Overlay */
        .fixed-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: url('Images/FieldBackground.jpg') center/cover no-repeat fixed; z-index: -10; }
        .fixed-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: -9; }

        /* Mouse Tracking Sun Glow */
        #sun_glow {
            position: fixed; width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(251, 192, 45, 0.6) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
            border-radius: 50%; pointer-events: none; z-index: -8; filter: blur(35px);
            left: -150px; top: -150px; 
            will-change: transform;
        }

        body { font-family: 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; color: var(--n-teal-dark); }

        /* Glassmorphism Form Container */
        .glass-form {
            background: var(--n-glass); backdrop-filter: blur(20px);
            padding: 45px; border-radius: 35px; border: 1px solid rgba(255,255,255,0.4);
            box-shadow: 0 25px 60px rgba(0,0,0,0.4); width: 420px; z-index: 1;
        }

        h2 { text-align: center; margin-top: 0; margin-bottom: 30px; font-weight: 800; color: var(--n-teal-dark); letter-spacing: -0.5px; }

        .form-group { margin-bottom: 22px; }
        label { display: block; margin-bottom: 8px; font-weight: 700; font-size: 0.9rem; opacity: 0.9; }

        /* Input and Select Styling */
        input, select {
            width: 100%; padding: 14px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.1);
            background: rgba(255,255,255,0.6); font-size: 1rem; color: var(--n-teal-dark);
            outline: none; box-sizing: border-box; transition: 0.3s;
        }
        input:focus, select:focus { border-color: var(--n-teal-med); background: white; box-shadow: 0 0 15px rgba(64,94,96,0.1); }

        .btn-save {
            width: 100%; padding: 16px; border-radius: 12px; border: none;
            background: var(--n-teal-med); color: white; font-weight: 800;
            font-size: 1.1rem; cursor: pointer; transition: 0.3s; margin-top: 15px;
        }
        .btn-save:hover { background: var(--n-teal-dark); transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.15); }

        .error-banner { background: rgba(211, 47, 47, 0.1); color: #d32f2f; padding: 12px; border-radius: 10px; margin-bottom: 25px; text-align: center; font-size: 0.85rem; border: 1px solid rgba(211, 47, 47, 0.2); }
        
        .back-link { display: block; text-align: center; margin-top: 20px; color: var(--n-teal-dark); text-decoration: none; font-weight: 700; font-size: 0.9rem; opacity: 0.6; transition: 0.3s; }
        .back-link:hover { opacity: 1; transform: scale(1.05); }
    </style>
</head>
<body>

    <div class="fixed-bg"></div>
    <div class="fixed-overlay"></div>
    <div id="sun_glow"></div>

    <div class="glass-form">
        <h2>Edit Panel Details</h2>
        
        <?php if($error_msg) echo "<div class='error-banner'>⚠️ $error_msg</div>"; ?>

        <form method="POST">
            <div class="form-group">
                <label>System Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($data['name']); ?>" required placeholder="e.g. Roof Array A">
            </div>
            
            <div class="form-group">
                <label>Site Location</label>
                <input type="text" name="location" value="<?php echo htmlspecialchars($data['location']); ?>" required placeholder="e.g. Riyadh Zone 1">
            </div>

            <div class="form-group">
                <label>Generation Capacity (0-400 W)</label>
                <input type="number" step="0.1" name="capacity" min="0" max="400" value="<?php echo $data['capacity']; ?>" required>
            </div>

            <div class="form-group">
                <label>Operational Status</label>
                <select name="status">
                    <option value="Active" <?php if($data['status'] == 'Active') echo 'selected'; ?>>Active</option>
                    <option value="Inactive" <?php if($data['status'] == 'Inactive') echo 'selected'; ?>>Inactive</option>
                </select>
            </div>

            <button type="submit" name="update_panel" class="btn-save">Update & Save</button>
            <a href="my_panels.php" class="back-link">← Cancel & Back to Home</a>
        </form>
    </div>

    <script>
        const glow = document.getElementById('sun_glow');
        // Smooth mouse tracking script
        document.addEventListener('mousemove', (e) => {
            window.requestAnimationFrame(() => {
                glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
            });
        });
    </script>
</body>
</html>