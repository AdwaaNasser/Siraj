<?php
$noura_conn = mysqli_connect("localhost", "root", "root", "siraj_db", 8889);

if ($noura_conn->connect_error) {
    die("Connection failed: " . $noura_conn->connect_error);
}
?>