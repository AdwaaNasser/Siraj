<?php
include("db_connect.php"); 

$allowedRole = 'admin';
require 'auth_guard.php';
require "db_connect.php";

$admin_id = $_SESSION['user_id'];

// -----------------------------
// Handle activate / deactivate
// -----------------------------
$message = "";

if (isset($_GET['message'])) {
    if ($_GET['message'] == "activated") {
        $message = "User activated successfully.";
    } elseif ($_GET['message'] == "deactivated") {
        $message = "User deactivated successfully.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['activate_user'])) {
        $userId = (int)$_POST['user_id'];
        $sql = "UPDATE users SET is_active = 1 WHERE user_id = $userId";
        mysqli_query($conn, $sql);

        header("Location: users.php?message=activated");
        exit();
    }

    if (isset($_POST['deactivate_user'])) {
        $userId = (int)$_POST['user_id'];
        $sql = "UPDATE users SET is_active = 0 WHERE user_id = $userId";
        mysqli_query($conn, $sql);

        header("Location: users.php?message=deactivated");
        exit();
    }
}

// -----------------------------
// Get filter / search / sort
// -----------------------------
$search = "";
$statusFilter = "all";
$sortBy = "name";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

if (isset($_GET['status'])) {
    $statusFilter = $_GET['status'];
}

if (isset($_GET['sort'])) {
    $sortBy = $_GET['sort'];
}

// -----------------------------
// Build query
// -----------------------------
$sql = "SELECT * FROM users WHERE role = 'panel_owner'";

// search
if (!empty($search)) {
    $searchEscaped = mysqli_real_escape_string($conn, $search);
    $sql .= " AND (name LIKE '%$searchEscaped%' OR email LIKE '%$searchEscaped%')";
}

// filter
if ($statusFilter == "active") {
    $sql .= " AND is_active = 1";
} elseif ($statusFilter == "inactive") {
    $sql .= " AND is_active = 0";
}

// sort
if ($sortBy == "date") {
    $sql .= " ORDER BY created_at ASC";
} else {
    $sql .= " ORDER BY name ASC";
}

$result = mysqli_query($conn, $sql);

$usersData = [];
if ($result && mysqli_num_rows($result) > 0) {
    mysqli_data_seek($result, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        $usersData[] = $row;
    }
}

$totalUsers = count($usersData);
$activeUsers = 0;
$inactiveUsers = 0;

foreach ($usersData as $user) {
    if ($user['is_active'] == 1) {
        $activeUsers++;
    } else {
        $inactiveUsers++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siraj | Manage Users</title>
    <style>
        h1,h2,h3,h4,p { margin:0; }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family:'Segoe UI', sans-serif;
            color:#314F52;
        }

        body::before {
            content:"";
            position:fixed;
            inset:0;
            background:url('Images/BlurrredBackground.jpg') center/cover no-repeat;
            filter:blur(8px);
            transform:scale(1.1);
            z-index:-2;
        }

        .container {
            padding:30px;
        }

        .logo-img {
            height: 60px;
            width: auto;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
        }

        .header-box {
            background: rgba(64, 94, 96, 0.85);
            border-radius: 25px;
            padding: 35px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            flex-wrap: wrap;
            gap: 18px;
        }

        .brand-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .brand-section h1 {
            margin: 0;
            line-height: 1;
            color: white;
        }

        .brand-section p {
            margin: 5px 0 0 0;
            color: white;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logout-btn {
            background: rgba(255,255,255,0.15);
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 10px;
            font-size: 13px;
            transition: 0.2s;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.25);
        }

        .message {
            background:#F8F4EB;
            color:#314F52;
            padding:14px 16px;
            border-radius:16px;
            margin-bottom:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .status-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
            gap:18px;
            margin-bottom:28px;
        }

        .status-card {
            background:#F8F4EB;
            padding:22px;
            border-radius:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        .status-card h4 {
            font-size:14px;
            color:#829193;
            margin-bottom:10px;
        }

        .value {
            font-size:26px;
            font-weight:bold;
            color:#314F52;
        }

        .sub {
            font-size:13px;
            margin-top:8px;
        }

        .warning {
            color:#d97706;
        }

        .positive {
            color:#2e7d32;
        }

        .card {
            background:#F8F4EB;
            padding:24px;
            border-radius:20px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
            margin-bottom:24px;
        }

        .card-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:16px;
            gap:10px;
        }

        .card h3 {
            color:#314F52;
        }

        .card-top span {
            font-size:12px;
            color:#829193;
        }

        .controls {
            display:grid;
            grid-template-columns:1.4fr 1fr 1fr auto;
            gap:12px;
        }

        .controls input,
        .controls select {
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 12px;
            border: 1px solid #829193;
            background: #ffffff;
            color: #314F52;
            outline:none;
        }

        .controls button {
            padding: 11px 14px;
            border-radius: 12px;
            font-size: 12px;
            border: none;
            background: #314F52;
            color: #F8F4EB;
            cursor: pointer;
            transition:0.2s;
        }

        .controls button:hover {
            background: #405E60;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            color: #314F52;
            min-width: 760px;
            background:white;
            border-radius:14px;
            overflow:hidden;
        }

        th, td {
            padding: 14px 12px;
            border-bottom: 1px solid #EDE9D2;
            text-align: left;
            font-size: 13px;
        }

        th {
            font-size: 12px;
            color: #829193;
            font-weight: bold;
            background: #F8F4EB;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .status-badge {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: bold;
        }

        .status-active {
            background: #EDE9D2;
            color: #314F52;
        }

        .status-inactive {
            background: #829193;
            color: #F8F4EB;
        }

        .action-form {
            display: inline;
        }

        .activate-btn,
        .deactivate-btn {
            padding: 9px 12px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 12px;
            color: #F8F4EB;
            transition:0.2s;
        }

        .activate-btn {
            background: #314F52;
        }

        .deactivate-btn {
            background: #405E60;
        }

        .activate-btn:hover,
        .deactivate-btn:hover {
            opacity: 0.92;
        }

        .no-users {
            background:#F8F4EB;
            padding:18px;
            border-radius:16px;
            color:#405E60;
            font-size:13px;
            box-shadow:0 4px 10px rgba(0,0,0,0.06);
        }

        #sun_glow {
            position: fixed;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(251, 192, 45, 0.5) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0; 
            filter: blur(35px);
            left: -150px;
            top: -150px;
            will-change: transform;
        }

        @media (max-width: 1000px) {
            .controls {
                grid-template-columns:1fr;
            }
        }

        @media (max-width: 700px) {
            .container {
                padding:18px;
            }

            .header-box {
                padding:24px;
            }

            .brand-section {
                flex-direction:column;
                align-items:flex-start;
            }
        }
    </style>
</head>
<body>
<div id="sun_glow"></div>

<div class="container">
    <div class="header-box">
        <div class="brand-section">
            <img src="Images/logo.png" alt="SIRAJ Logo" class="logo-img">
            <div>
                <h1>Manage Users</h1>
                <p>Manage and monitor all users efficiently from one centralized dashboard.</p>
            </div>
        </div>

        <div class="header-actions">
            <a href="admin_dashboard.php" class="logout-btn">Dashboard</a>
            <a href="logout.php" class="logout-btn">Log-Out</a>
        </div>
    </div>

    <?php if (!empty($message)) { ?>
        <div class="message"><?php echo $message; ?></div>
    <?php } ?>

    <div class="status-grid">
        <div class="status-card">
            <h4>Total Users</h4>
            <div class="value"><?php echo $totalUsers; ?></div>
            <div class="sub positive">Panel owner accounts</div>
        </div>

        <div class="status-card">
            <h4>Active Users</h4>
            <div class="value"><?php echo $activeUsers; ?></div>
            <div class="sub positive">Currently active accounts</div>
        </div>

        <div class="status-card">
            <h4>Inactive Users</h4>
            <div class="value"><?php echo $inactiveUsers; ?></div>
            <div class="sub warning">Accounts needing activation</div>
        </div>
    </div>

    <div class="card">
        <div class="card-top">
            <h3>Filter Users</h3>
            <span>Search / Sort / Status</span>
        </div>

        <form method="GET" class="controls">
            <input type="text" name="search" placeholder="Search by name or email"
                   value="<?php echo htmlspecialchars($search); ?>">

            <select name="status">
                <option value="all" <?php if ($statusFilter == "all") echo "selected"; ?>>All Users</option>
                <option value="active" <?php if ($statusFilter == "active") echo "selected"; ?>>Active Users</option>
                <option value="inactive" <?php if ($statusFilter == "inactive") echo "selected"; ?>>Inactive Users</option>
            </select>

            <select name="sort">
                <option value="name" <?php if ($sortBy == "name") echo "selected"; ?>>Sort by Name</option>
                <option value="date" <?php if ($sortBy == "date") echo "selected"; ?>>Sort by Date Joined</option>
            </select>

            <button type="submit">Apply</button>
        </form>
    </div>

    <?php if (!empty($usersData)) { ?>
        <div class="card">
            <div class="card-top">
                <h3>Users List</h3>
                <span><?php echo $totalUsers; ?> Result(s)</span>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Date Joined</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usersData as $row) { ?>
                            <tr>
                                <td><?php echo $row['user_id']; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                                <td>
                                    <?php if ($row['is_active'] == 1) { ?>
                                        <span class="status-badge status-active">Active</span>
                                    <?php } else { ?>
                                        <span class="status-badge status-inactive">Inactive</span>
                                    <?php } ?>
                                </td>
                                <td>
                                    <form method="POST" class="action-form">
                                        <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">

                                        <?php if ($row['is_active'] == 1) { ?>
                                            <button type="submit" name="deactivate_user" class="deactivate-btn">Deactivate</button>
                                        <?php } else { ?>
                                            <button type="submit" name="activate_user" class="activate-btn">Activate</button>
                                        <?php } ?>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php } else { ?>
        <div class="no-users">
            No users found.
        </div>
    <?php } ?>
</div>

<script>
    const sun = document.getElementById('sun_glow');
    document.addEventListener('mousemove', (e) => {
        sun.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    });
</script>
</body>
</html>