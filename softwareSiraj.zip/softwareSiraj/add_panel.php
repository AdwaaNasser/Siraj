<?php
include('db_connect.php');

$allowedRole = 'panel_owner';
require 'auth_guard.php';

$error_msg = "";

// 1. Get current logged-in user from session
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect if session is lost
    exit();
}
$current_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 2. Sanitize input data
    $noura_name = mysqli_real_escape_string($conn, $_POST['noura_name']);
    $noura_cap = floatval($_POST['noura_cap']);
    $noura_loc = mysqli_real_escape_string($conn, $_POST['noura_loc']);

    // 3. Validate Capacity range
    if ($noura_cap < 0 || $noura_cap > 400) {
        $error_msg = "Error: Capacity must be between 0 and 400 W.";
    } else {
        // 4. Check for duplicate panel names for this specific user
        $noura_check = mysqli_query($conn, "SELECT * FROM panel WHERE name = '$noura_name' AND userID = '$current_user_id'");
        if (mysqli_num_rows($noura_check) > 0) {
            $error_msg = "Error: You already have a panel with this name.";
        } else {
            // 5. Automatically create a linked Storage Unit
            $sql_storage = "INSERT INTO storage_unit (capacity, currentLevel, status) VALUES (15.0, 0.0, 'Low')";
            if (mysqli_query($conn, $sql_storage)) {
                $noura_s_id = mysqli_insert_id($conn);

                // 6. Add the new Panel
                $sql_panel = "INSERT INTO panel (name, capacity, location, status, storageID, userID) 
                              VALUES ('$noura_name', '$noura_cap', '$noura_loc', 'Active', '$noura_s_id', '$current_user_id')";

                if (mysqli_query($conn, $sql_panel)) {
                    $noura_p_id = mysqli_insert_id($conn);

                    // Static initial reading values
                    $n_temp = 34.2;
                    $n_sun = 980.5;
                    $n_dust = 12.0;
                    $n_volt = 220.0;

                    // 7. Initialize 4 sensors and their first readings
                    $sensor_map = [
                        ['temperature sensor', '°C', $n_temp],
                        ['sunlight sensor', 'W/m²', $n_sun],
                        ['dust sensor', '%', $n_dust],
                        ['voltage sensor', 'V', $n_volt]
                    ];

                    foreach ($sensor_map as $s) {
                        mysqli_query($conn, "INSERT INTO sensor (type, unit, status, panelID) VALUES ('$s[0]', '$s[1]', 'Active', '$noura_p_id')");
                        $new_s_id = mysqli_insert_id($conn);
                        mysqli_query($conn, "INSERT INTO reading (value, timestamp, sensorID) VALUES ('$s[2]', NOW(), '$new_s_id')");
                    }

                    // 8. Add initial Environmental record
                    mysqli_query($conn, "INSERT INTO enviromentaldata (weatherCondition, ambientTemperature, dustAccumulation, sunlightIntensity, timestamp, panelID) 
                                VALUES ('Sunny', '$n_temp', '$n_dust', '$n_sun', NOW(), '$noura_p_id')");

                    $_SESSION['success_msg'] = "Panel '$noura_name' and all sensors added successfully!";
                    header("Location: my_panels.php");
                    exit();
                }
            } else {
                $error_msg = "Database Error: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SIRAJ | Add Panel</title>
        <style>
            :root {
                --n-teal-med: #405E60;
                --n-teal-dark: #314F52;
                --n-cream-light: #f8f4eb;
                --n-sun-yellow: #fbc02d;
                --n-glass: rgba(255, 255, 255, 0.75);
            }

            html, body {
                height: 100%;
                margin: 0;
                padding: 0;
                overflow: hidden;
            }

            /* Fixed Background */
            .fixed-bg {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: url('Images/FieldBackground.jpg') center/cover no-repeat fixed;
                z-index: -10;
            }
            .fixed-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: -9;
            }

            /* Mouse tracking glow effect */
            #sun_glow {
                position: fixed;
                width: 300px;
                height: 300px;
                background: radial-gradient(circle, rgba(251, 192, 45, 0.6) 0%, rgba(251, 192, 45, 0.2) 40%, transparent 70%);
                border-radius: 50%;
                pointer-events: none;
                z-index: -8;
                filter: blur(35px);
                left: -150px;
                top: -150px;
                will-change: transform;
            }

            body {
                font-family: 'Segoe UI', sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                color: var(--n-teal-dark);
            }

            .glass-form {
                background: var(--n-glass);
                backdrop-filter: blur(20px);
                padding: 45px;
                border-radius: 35px;
                border: 1px solid rgba(255,255,255,0.4);
                box-shadow: 0 25px 60px rgba(0,0,0,0.4);
                width: 420px;
                z-index: 1;
            }

            h2 {
                text-align: center;
                margin-top: 0;
                margin-bottom: 30px;
                font-weight: 800;
                color: var(--n-teal-dark);
            }

            .form-group {
                margin-bottom: 22px;
            }
            label {
                display: block;
                margin-bottom: 8px;
                font-weight: 700;
                font-size: 0.9rem;
            }

            input {
                width: 100%;
                padding: 14px;
                border-radius: 12px;
                border: 1px solid rgba(0,0,0,0.1);
                background: rgba(255,255,255,0.6);
                font-size: 1rem;
                color: var(--n-teal-dark);
                outline: none;
                box-sizing: border-box;
                transition: 0.3s;
            }
            input:focus {
                border-color: var(--n-teal-med);
                background: white;
                box-shadow: 0 0 15px rgba(64,94,96,0.1);
            }

            .btn-add {
                width: 100%;
                padding: 16px;
                border-radius: 12px;
                border: none;
                background: var(--n-teal-med);
                color: white;
                font-weight: 800;
                font-size: 1.1rem;
                cursor: pointer;
                transition: 0.3s;
                margin-top: 15px;
            }
            .btn-add:hover {
                background: var(--n-teal-dark);
                transform: translateY(-3px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            }

            .error-banner {
                background: rgba(211, 47, 47, 0.1);
                color: #d32f2f;
                padding: 12px;
                border-radius: 10px;
                margin-bottom: 25px;
                text-align: center;
                font-size: 0.85rem;
                border: 1px solid rgba(211, 47, 47, 0.2);
            }

            .back-link {
                display: block;
                text-align: center;
                margin-top: 20px;
                color: var(--n-teal-dark);
                text-decoration: none;
                font-weight: 700;
                font-size: 0.9rem;
                opacity: 0.6;
                transition: 0.3s;
            }
            .back-link:hover {
                opacity: 1;
                transform: scale(1.05);
            }
        </style>
    </head>
    <body>

        <div class="fixed-bg"></div>
        <div class="fixed-overlay"></div>
        <div id="sun_glow"></div>

        <div class="glass-form">
            <h2>Add Panel</h2>

<?php if ($error_msg) echo "<div class='error-banner'>⚠️ $error_msg</div>"; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="noura_name" required placeholder="e.g. Garden Array" value="<?php echo isset($_POST['noura_name']) ? htmlspecialchars($_POST['noura_name']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="noura_loc" required placeholder="e.g. Zone 3 North" value="<?php echo isset($_POST['noura_loc']) ? htmlspecialchars($_POST['noura_loc']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label>Capacity (0-400 W)</label>
                    <input type="number" step="0.1" name="noura_cap" min="0" max="400" required placeholder="Max 400" value="<?php echo isset($_POST['noura_cap']) ? htmlspecialchars($_POST['noura_cap']) : ''; ?>">
                </div>

                <button type="submit" class="btn-add">Confirm & Add Panel</button>
                <a href="my_panels.php" class="back-link">← Cancel & Back to Home</a>
            </form>
        </div>

        <script>
            const glow = document.getElementById('sun_glow');
            // Smooth cursor tracking
            document.addEventListener('mousemove', (e) => {
                window.requestAnimationFrame(() => {
                    glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
                });
            });
        </script>
    </body>
</html>