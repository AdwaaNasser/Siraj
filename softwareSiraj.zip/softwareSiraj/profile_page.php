<?php
$allowedRole = 'panel_owner';
require 'auth_guard.php';

$userID = $_SESSION['user_id'] ?? 1;
$userRole = $_SESSION['role'] ?? 'user';
require "db_connect.php";

$sql = "SELECT name,email,password_hash,profile_pic FROM users WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$name = $user['name'];
$email = $user['email'];
$profilepic = !empty($user['profile_pic']) ? $user['profile_pic'] : 'Images/user.png';?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <link rel="stylesheet" href="stylee.css">
</head>

<body class="profile-page">

<<!-- Success notification (JS-controlled) -->
    <div id="success-message" class="message" style="display: none;">
        <!-- Success message will be injected here -->
    </div>


    <?php
    // If there's a session message, show it
    if (isset($_SESSION['message'])): ?>
        <script>
        window.addEventListener("load", function() {
            var el = document.getElementById("success-message");
            el.innerText = "<?php echo $_SESSION['message']; ?>";
            el.style.display = "block";
            setTimeout(function() {
                el.style.display = "none"; // Hide after 3 seconds
            }, 3000);
        });
        </script>
        <?php unset($_SESSION['message']); endif; ?>

<div class="profile-container">

    <div class="profile-header">
        <button id="back-btn" style="background-color: #F8F4EB; color: #405E60; border: none;">← Back</button>
         <script>
        // Get the user's role from PHP (via embedded PHP variable)
        const userRole = "<?php echo $userRole; ?>";  // Can be 'admin' or 'user'

        // Add an event listener to the "Back" button
        document.getElementById("back-btn").addEventListener("click", function() {
            // Redirect based on the user's role
            if (userRole === "admin") {
                window.location.href = "admin_dashboard.php";  // Redirect to admin dashboard
            } else {
                window.location.href = "user_dashboard.php";   // Redirect to user dashboard
            }
        });
    </script>
        
        <h1>My Profile Page</h1>
        <img id="edit-icon" src="Images/edit.png" style="cursor:pointer">
        <p class="sub">View your personal information</p>
    </div>

    <form class="profile-info" action="update-profile.php" method="POST" enctype="multipart/form-data">

        <div class="info-group">
            <img id="profile-pic" src="<?php echo htmlspecialchars($profilepic); ?>" width="120">
            <input type="file" name="profilepic" id="profile-upload" accept="image/*" disabled>
        </div>

        <div class="info-group">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" disabled>
        </div>

        <div class="info-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" disabled>
        </div>


        <button id="save-btn" type="submit" style="display:none;">
            Update & Save
        </button>

    </form>

    <form action="delete_account.php" method="POST">
        <button type="submit" class="delete-account-btn" id="delete-account-btn">
            <img src="Images/delete-icon.png" class="delete-icon" alt="Delete Icon">
            <span class="delete-text">Delete Account</span>
        </button>
    </form>

</div>

<script src="script.js"></script>



</body>
</html>