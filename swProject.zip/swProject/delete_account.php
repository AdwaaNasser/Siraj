<?php
require "config.php";

$userId = 4; // لاحقاً نخليه session




// أخيراً حذف المستخدم
$conn->query("DELETE FROM users WHERE user_id = $userId");

// تحويل لصفحة ثانية
header("Location: notificaion-page.php");
exit();
?>